-- MySQL dump 10.13  Distrib 8.4.10, for Linux (x86_64)
--
-- Host: localhost    Database: fixit_data
-- ------------------------------------------------------
-- Server version	8.4.10-0ubuntu0.26.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_log`
--

DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_log` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint unsigned DEFAULT NULL,
  `causer_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint unsigned DEFAULT NULL,
  `properties` json DEFAULT NULL,
  `batch_uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subject` (`subject_type`,`subject_id`),
  KEY `causer` (`causer_type`,`causer_id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_log`
--

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
INSERT INTO `activity_log` VALUES (1,'Category','B2C - Category has been created','App\\Models\\Category','created',1,'App\\Models\\User',17,'{\"attributes\": {\"id\": 1, \"slug\": \"b2c\", \"title\": \"B2C\", \"status\": 1, \"parent_id\": null, \"commission\": 1, \"created_at\": \"2026-05-28T13:16:06.000000Z\", \"created_by\": 17, \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-05-28T13:16:06.000000Z\", \"description\": \"Сервис для частных лиц\", \"is_featured\": 1, \"category_type\": \"service\", \"services_count\": 0, \"meta_description\": null}}',NULL,'2026-05-28 10:16:06','2026-05-28 10:16:06'),(2,'Category','B2C - Category has been deleted','App\\Models\\Category','deleted',1,'App\\Models\\User',17,'{\"old\": {\"id\": 1, \"slug\": \"b2c\", \"title\": \"B2C\", \"status\": 1, \"parent_id\": null, \"commission\": 1, \"created_at\": \"2026-05-28T13:16:06.000000Z\", \"created_by\": 17, \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-05-28T13:16:06.000000Z\", \"description\": \"Сервис для частных лиц\", \"is_featured\": 1, \"category_type\": \"service\", \"services_count\": 0, \"meta_description\": null}}',NULL,'2026-05-28 10:16:25','2026-05-28 10:16:25'),(3,'Category','Уборка квартир - Category has been created','App\\Models\\Category','created',2,'App\\Models\\User',17,'{\"attributes\": {\"id\": 2, \"slug\": \"uborka-kvartir\", \"title\": \"Уборка квартир\", \"status\": 1, \"parent_id\": null, \"commission\": 5, \"created_at\": \"2026-05-28T13:18:10.000000Z\", \"created_by\": 17, \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-05-28T13:18:10.000000Z\", \"description\": \"Закажите уборку квартиры у проверенного мастера — быстро, предсказуемо, с гарантией. Каждый клинер проходит верификацию по паспорту перед допуском к работе, а стоимость вы видите ещё до оформления заказа: никаких доплат и сюрпризов на месте. Поддерживающая уборка, генеральная или уборка после ремонта — выберите подходящий формат, удобную дату и время. Все заказы застрахованы, а после визита вы оцениваете работу мастера. Платите онлайн, отслеживайте мастера на карте, получайте чистый дом без лишних хлопот.\", \"is_featured\": 1, \"category_type\": \"service\", \"services_count\": 0, \"meta_description\": null}}',NULL,'2026-05-28 10:18:10','2026-05-28 10:18:10'),(4,'Category','Уборка офисов и коммерческих помещений - Category has been created','App\\Models\\Category','created',3,'App\\Models\\User',17,'{\"attributes\": {\"id\": 3, \"slug\": \"uborka-ofisov-i-kommercheskih-pomeshcheniy\", \"title\": \"Уборка офисов и коммерческих помещений\", \"status\": 1, \"parent_id\": null, \"commission\": 5, \"created_at\": \"2026-05-28T13:18:34.000000Z\", \"created_by\": 17, \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-05-28T13:18:34.000000Z\", \"description\": \"Профессиональная уборка коммерческих помещений для компаний любого масштаба — офисы, кафе, рестораны, коворкинги, шоурумы и салоны. Работаем по договору с полным пакетом закрывающих документов: акты и счета для вашей бухгалтерии. Настройте регулярный график — ежедневно, несколько раз в неделю или разово — и получайте стабильное качество без необходимости держать клинера в штате. Каждый исполнитель верифицирован, каждый выезд застрахован. Прозрачная фиксированная стоимость, оплата онлайн или по безналичному расчёту, персональный менеджер для корпоративных клиентов.\", \"is_featured\": 1, \"category_type\": \"service\", \"services_count\": 0, \"meta_description\": null}}',NULL,'2026-05-28 10:18:34','2026-05-28 10:18:34'),(5,'Category','Мастер на час - Category has been created','App\\Models\\Category','created',4,'App\\Models\\User',17,'{\"attributes\": {\"id\": 4, \"slug\": \"master-na-chas\", \"title\": \"Мастер на час\", \"status\": 1, \"parent_id\": null, \"commission\": 5, \"created_at\": \"2026-05-28T13:18:55.000000Z\", \"created_by\": 17, \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-05-28T13:18:55.000000Z\", \"description\": \"Универсальный мастер для любых бытовых задач по дому и в офисе. Повесить полку, карниз или зеркало, установить смеситель, заменить розетку, собрать мебель, починить мелкую неисправность — закажите мастера на час и решите сразу несколько задач за один визит. Стоимость известна заранее, мастер верифицирован по паспорту, работа застрахована. Выбирайте удобное время, отслеживайте прибытие на карте и оценивайте результат. Надёжный помощник для дома — без поиска по объявлениям и торга.\", \"is_featured\": 1, \"category_type\": \"service\", \"services_count\": 0, \"meta_description\": null}}',NULL,'2026-05-28 10:18:55','2026-05-28 10:18:55'),(6,'Category','Поддерживающая уборка - Category has been created','App\\Models\\Category','created',5,'App\\Models\\User',17,'{\"attributes\": {\"id\": 5, \"slug\": \"podderzhivayushchaya-uborka\", \"title\": \"Поддерживающая уборка\", \"status\": 1, \"parent_id\": 2, \"commission\": 5, \"created_at\": \"2026-06-30T12:29:30.000000Z\", \"created_by\": 17, \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-06-30T12:29:30.000000Z\", \"description\": \"1\", \"is_featured\": 1, \"category_type\": \"service\", \"services_count\": 0, \"meta_description\": null}}',NULL,'2026-06-30 09:29:30','2026-06-30 09:29:30'),(7,'Service','Поддерживающая уборка до 50 м² - Service has been created','App\\Models\\Service','created',1,'App\\Models\\User',17,'{\"attributes\": {\"id\": 1, \"slug\": \"podderzhivayushchaya-uborka-do-50-m2\", \"type\": \"fixed\", \"price\": 5000, \"title\": \"Поддерживающая уборка до 50 м²\", \"video\": \"\", \"status\": 1, \"content\": \"<p>Регулярная уборка для квартир-студий и однокомнатных. Влажная уборка пола, вытирание пыли, мытьё санузла и кухонных поверхностей, вынос мусора. Длительность 2 часа.</p>\", \"user_id\": null, \"discount\": null, \"duration\": \"2\", \"parent_id\": null, \"address_id\": null, \"created_at\": \"2026-06-30T13:18:58.000000Z\", \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-06-30T13:18:58.000000Z\", \"description\": \"\", \"is_featured\": 0, \"service_rate\": 5000, \"created_by_id\": 17, \"duration_unit\": \"hours\", \"is_advertised\": 0, \"reviews_count\": 0, \"bookings_count\": 0, \"is_custom_offer\": 0, \"meta_description\": null, \"required_servicemen\": 2, \"speciality_description\": null, \"per_serviceman_commission\": 5, \"advance_payment_percentage\": null, \"is_advance_payment_enabled\": false, \"is_random_related_services\": 0}}',NULL,'2026-06-30 10:18:58','2026-06-30 10:18:58'),(8,'Service','Поддерживающая уборка до 50 м² - Service has been updated','App\\Models\\Service','updated',1,'App\\Models\\User',17,'{\"old\": {\"id\": 1, \"slug\": \"podderzhivayushchaya-uborka-do-50-m2\", \"type\": \"fixed\", \"price\": 5000, \"title\": \"Поддерживающая уборка до 50 м²\", \"video\": \"\", \"status\": 1, \"content\": \"<p>Регулярная уборка для квартир-студий и однокомнатных. Влажная уборка пола, вытирание пыли, мытьё санузла и кухонных поверхностей, вынос мусора. Длительность 2 часа.</p>\", \"user_id\": null, \"discount\": null, \"duration\": \"2\", \"parent_id\": null, \"address_id\": null, \"created_at\": \"2026-06-30T13:18:58.000000Z\", \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-06-30T13:18:58.000000Z\", \"description\": \"\", \"is_featured\": 0, \"service_rate\": 5000, \"created_by_id\": 17, \"duration_unit\": \"hours\", \"is_advertised\": null, \"reviews_count\": null, \"bookings_count\": null, \"is_custom_offer\": null, \"meta_description\": null, \"required_servicemen\": 2, \"speciality_description\": null, \"per_serviceman_commission\": 5, \"advance_payment_percentage\": null, \"is_advance_payment_enabled\": false, \"is_random_related_services\": \"0\"}, \"attributes\": {\"id\": 1, \"slug\": \"podderzhivayushchaya-uborka-do-50-m2\", \"type\": \"fixed\", \"price\": 5000, \"title\": \"Поддерживающая уборка до 50 м²\", \"video\": \"\", \"status\": 1, \"content\": \"<p>Регулярная уборка для квартир-студий и однокомнатных. Влажная уборка пола, вытирание пыли, мытьё санузла и кухонных поверхностей, вынос мусора. Длительность 2 часа.</p>\", \"user_id\": null, \"discount\": null, \"duration\": \"2\", \"parent_id\": null, \"address_id\": null, \"created_at\": \"2026-06-30T13:18:58.000000Z\", \"deleted_at\": null, \"meta_title\": \"\", \"updated_at\": \"2026-06-30T13:18:58.000000Z\", \"description\": \"\", \"is_featured\": 0, \"service_rate\": 5000, \"created_by_id\": 17, \"duration_unit\": \"hours\", \"is_advertised\": 0, \"reviews_count\": 0, \"bookings_count\": 0, \"is_custom_offer\": 0, \"meta_description\": \"\", \"required_servicemen\": 2, \"speciality_description\": \"\", \"per_serviceman_commission\": 5, \"advance_payment_percentage\": null, \"is_advance_payment_enabled\": false, \"is_random_related_services\": 0}}',NULL,'2026-06-30 10:18:58','2026-06-30 10:18:58'),(9,'Service','Поддерживающая уборка 50–100 м² - Service has been created','App\\Models\\Service','created',2,'App\\Models\\User',17,'{\"attributes\": {\"id\": 2, \"slug\": \"podderzhivayushchaya-uborka-50-100-m2\", \"type\": \"fixed\", \"price\": 10000, \"title\": \"Поддерживающая уборка 50–100 м²\", \"video\": \"\", \"status\": 1, \"content\": \"<p>Регулярная уборка для двух- и трёхкомнатных квартир. Все поверхности, санузел, кухня, полы. Длительность 3 часа.</p>\", \"user_id\": null, \"discount\": null, \"duration\": \"3\", \"parent_id\": null, \"address_id\": null, \"created_at\": \"2026-06-30T14:01:40.000000Z\", \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-06-30T14:01:40.000000Z\", \"description\": \"\", \"is_featured\": 0, \"service_rate\": 10000, \"created_by_id\": 17, \"duration_unit\": \"hours\", \"is_advertised\": 0, \"reviews_count\": 0, \"bookings_count\": 0, \"is_custom_offer\": 0, \"meta_description\": null, \"required_servicemen\": 2, \"speciality_description\": null, \"per_serviceman_commission\": 5, \"advance_payment_percentage\": null, \"is_advance_payment_enabled\": false, \"is_random_related_services\": 0}}',NULL,'2026-06-30 11:01:40','2026-06-30 11:01:40'),(10,'Service','Поддерживающая уборка 50–100 м² - Service has been updated','App\\Models\\Service','updated',2,'App\\Models\\User',17,'{\"old\": {\"id\": 2, \"slug\": \"podderzhivayushchaya-uborka-50-100-m2\", \"type\": \"fixed\", \"price\": 10000, \"title\": \"Поддерживающая уборка 50–100 м²\", \"video\": \"\", \"status\": 1, \"content\": \"<p>Регулярная уборка для двух- и трёхкомнатных квартир. Все поверхности, санузел, кухня, полы. Длительность 3 часа.</p>\", \"user_id\": null, \"discount\": null, \"duration\": \"3\", \"parent_id\": null, \"address_id\": null, \"created_at\": \"2026-06-30T14:01:40.000000Z\", \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-06-30T14:01:40.000000Z\", \"description\": \"\", \"is_featured\": 0, \"service_rate\": 10000, \"created_by_id\": 17, \"duration_unit\": \"hours\", \"is_advertised\": null, \"reviews_count\": null, \"bookings_count\": null, \"is_custom_offer\": null, \"meta_description\": null, \"required_servicemen\": 2, \"speciality_description\": null, \"per_serviceman_commission\": 5, \"advance_payment_percentage\": null, \"is_advance_payment_enabled\": false, \"is_random_related_services\": \"0\"}, \"attributes\": {\"id\": 2, \"slug\": \"podderzhivayushchaya-uborka-50-100-m2\", \"type\": \"fixed\", \"price\": 10000, \"title\": \"Поддерживающая уборка 50–100 м²\", \"video\": \"\", \"status\": 1, \"content\": \"<p>Регулярная уборка для двух- и трёхкомнатных квартир. Все поверхности, санузел, кухня, полы. Длительность 3 часа.</p>\", \"user_id\": null, \"discount\": null, \"duration\": \"3\", \"parent_id\": null, \"address_id\": null, \"created_at\": \"2026-06-30T14:01:40.000000Z\", \"deleted_at\": null, \"meta_title\": \"\", \"updated_at\": \"2026-06-30T14:01:40.000000Z\", \"description\": \"\", \"is_featured\": 0, \"service_rate\": 10000, \"created_by_id\": 17, \"duration_unit\": \"hours\", \"is_advertised\": 0, \"reviews_count\": 0, \"bookings_count\": 0, \"is_custom_offer\": 0, \"meta_description\": \"\", \"required_servicemen\": 2, \"speciality_description\": \"\", \"per_serviceman_commission\": 5, \"advance_payment_percentage\": null, \"is_advance_payment_enabled\": false, \"is_random_related_services\": 0}}',NULL,'2026-06-30 11:01:40','2026-06-30 11:01:40'),(11,'Category','Генеральная уборка - Category has been created','App\\Models\\Category','created',6,'App\\Models\\User',17,'{\"attributes\": {\"id\": 6, \"slug\": \"generalnaya-uborka\", \"title\": \"Генеральная уборка\", \"status\": 1, \"parent_id\": 2, \"commission\": 5, \"created_at\": \"2026-06-30T14:04:02.000000Z\", \"created_by\": 17, \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-06-30T14:04:02.000000Z\", \"description\": \"1\", \"is_featured\": 1, \"category_type\": \"service\", \"services_count\": 0, \"meta_description\": null}}',NULL,'2026-06-30 11:04:02','2026-06-30 11:04:02'),(12,'Category','Специальная уборка - Category has been created','App\\Models\\Category','created',7,'App\\Models\\User',17,'{\"attributes\": {\"id\": 7, \"slug\": \"specialnaya-uborka\", \"title\": \"Специальная уборка\", \"status\": 1, \"parent_id\": 2, \"commission\": 5, \"created_at\": \"2026-06-30T14:04:22.000000Z\", \"created_by\": 17, \"deleted_at\": null, \"meta_title\": null, \"updated_at\": \"2026-06-30T14:04:22.000000Z\", \"description\": \"1\", \"is_featured\": 1, \"category_type\": \"service\", \"services_count\": 0, \"meta_description\": null}}',NULL,'2026-06-30 11:04:22','2026-06-30 11:04:22');
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `latitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postal_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_id` bigint unsigned NOT NULL,
  `state_id` bigint unsigned DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternative_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` bigint DEFAULT NULL,
  `alternative_phone` bigint DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `company_id` bigint unsigned DEFAULT NULL,
  `availability_radius` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_user_id_foreign` (`user_id`),
  KEY `addresses_service_id_foreign` (`service_id`),
  KEY `addresses_country_id_foreign` (`country_id`),
  KEY `addresses_state_id_foreign` (`state_id`),
  KEY `addresses_company_id_foreign` (`company_id`),
  CONSTRAINT `addresses_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_state_id_foreign` FOREIGN KEY (`state_id`) REFERENCES `states` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertisement_services`
--

DROP TABLE IF EXISTS `advertisement_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advertisement_services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `advertisement_id` bigint unsigned NOT NULL,
  `service_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `advertisement_services_advertisement_id_foreign` (`advertisement_id`),
  KEY `advertisement_services_service_id_foreign` (`service_id`),
  CONSTRAINT `advertisement_services_advertisement_id_foreign` FOREIGN KEY (`advertisement_id`) REFERENCES `advertisements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `advertisement_services_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertisement_services`
--

LOCK TABLES `advertisement_services` WRITE;
/*!40000 ALTER TABLE `advertisement_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `advertisement_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `advertisements`
--

DROP TABLE IF EXISTS `advertisements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `advertisements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `provider_id` bigint unsigned DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `screen` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `zone` bigint unsigned DEFAULT NULL,
  `status` enum('pending','approved','rejected','running','paused','expired') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `advertisements_created_by_foreign` (`created_by`),
  KEY `advertisements_provider_id_foreign` (`provider_id`),
  KEY `advertisements_zone_foreign` (`zone`),
  CONSTRAINT `advertisements_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `advertisements_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `advertisements_zone_foreign` FOREIGN KEY (`zone`) REFERENCES `zones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `advertisements`
--

LOCK TABLES `advertisements` WRITE;
/*!40000 ALTER TABLE `advertisements` DISABLE KEYS */;
/*!40000 ALTER TABLE `advertisements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_logs`
--

DROP TABLE IF EXISTS `backup_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `file_path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_logs`
--

LOCK TABLES `backup_logs` WRITE;
/*!40000 ALTER TABLE `backup_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `backup_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_details`
--

DROP TABLE IF EXISTS `bank_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `holder_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `branch_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ifsc_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `swift_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank_details`
--

LOCK TABLES `bank_details` WRITE;
/*!40000 ALTER TABLE `bank_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banner_zones`
--

DROP TABLE IF EXISTS `banner_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `banner_zones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `banner_id` bigint unsigned NOT NULL,
  `zone_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `banner_zones_banner_id_foreign` (`banner_id`),
  KEY `banner_zones_zone_id_foreign` (`zone_id`),
  CONSTRAINT `banner_zones_banner_id_foreign` FOREIGN KEY (`banner_id`) REFERENCES `banners` (`id`) ON DELETE CASCADE,
  CONSTRAINT `banner_zones_zone_id_foreign` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banner_zones`
--

LOCK TABLES `banner_zones` WRITE;
/*!40000 ALTER TABLE `banner_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_id` bigint DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_offer` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `banners_created_by_foreign` (`created_by`),
  CONSTRAINT `banners_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bids`
--

DROP TABLE IF EXISTS `bids`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bids` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `service_request_id` bigint unsigned DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(8,4) DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `status` enum('rejected','accepted','requested') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bids_service_request_id_foreign` (`service_request_id`),
  KEY `bids_provider_id_foreign` (`provider_id`),
  CONSTRAINT `bids_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bids_service_request_id_foreign` FOREIGN KEY (`service_request_id`) REFERENCES `service_requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bids`
--

LOCK TABLES `bids` WRITE;
/*!40000 ALTER TABLE `bids` DISABLE KEYS */;
/*!40000 ALTER TABLE `bids` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_categories_blog_id_foreign` (`blog_id`),
  KEY `blog_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `blog_categories_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blog_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_categories`
--

LOCK TABLES `blog_categories` WRITE;
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_tags`
--

DROP TABLE IF EXISTS `blog_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` bigint unsigned NOT NULL,
  `tag_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_tags_blog_id_foreign` (`blog_id`),
  KEY `blog_tags_tag_id_foreign` (`tag_id`),
  CONSTRAINT `blog_tags_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blog_tags_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_tags`
--

LOCK TABLES `blog_tags` WRITE;
/*!40000 ALTER TABLE `blog_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext COLLATE utf8mb4_unicode_ci,
  `is_featured` int NOT NULL DEFAULT '0',
  `status` int NOT NULL DEFAULT '1',
  `created_by_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blogs_slug_unique` (`slug`),
  KEY `blogs_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `blogs_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_additional_services`
--

DROP TABLE IF EXISTS `booking_additional_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_additional_services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint unsigned NOT NULL,
  `additional_service_id` bigint unsigned NOT NULL,
  `qty` int unsigned NOT NULL DEFAULT '1',
  `price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_additional_services_booking_id_foreign` (`booking_id`),
  KEY `booking_additional_services_additional_service_id_foreign` (`additional_service_id`),
  CONSTRAINT `booking_additional_services_additional_service_id_foreign` FOREIGN KEY (`additional_service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `booking_additional_services_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_additional_services`
--

LOCK TABLES `booking_additional_services` WRITE;
/*!40000 ALTER TABLE `booking_additional_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_additional_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_payment_transactions`
--

DROP TABLE IF EXISTS `booking_payment_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_payment_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint unsigned NOT NULL,
  `payment_transaction_id` bigint unsigned NOT NULL,
  `payment_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full' COMMENT 'advance, remaining, full',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_payment_transactions_payment_transaction_id_foreign` (`payment_transaction_id`),
  KEY `idx_booking_payment_trans` (`booking_id`,`payment_transaction_id`),
  CONSTRAINT `booking_payment_transactions_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `booking_payment_transactions_payment_transaction_id_foreign` FOREIGN KEY (`payment_transaction_id`) REFERENCES `payment_gateways_transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_payment_transactions`
--

LOCK TABLES `booking_payment_transactions` WRITE;
/*!40000 ALTER TABLE `booking_payment_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_payment_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_reason_logs`
--

DROP TABLE IF EXISTS `booking_reason_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_reason_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint unsigned NOT NULL,
  `status_id` bigint unsigned NOT NULL,
  `reason` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_reason_logs_booking_id_foreign` (`booking_id`),
  KEY `booking_reason_logs_status_id_foreign` (`status_id`),
  CONSTRAINT `booking_reason_logs_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `booking_reason_logs_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `booking_status` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_reason_logs`
--

LOCK TABLES `booking_reason_logs` WRITE;
/*!40000 ALTER TABLE `booking_reason_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_reason_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_service`
--

DROP TABLE IF EXISTS `booking_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_service` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint unsigned DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  `service_package_id` bigint unsigned DEFAULT NULL,
  `service_price` decimal(8,2) DEFAULT NULL,
  `tax` decimal(8,2) DEFAULT NULL,
  `per_serviceman_charge` decimal(8,2) DEFAULT NULL,
  `total_extra_servicemen` decimal(8,2) DEFAULT NULL,
  `total_extra_servicemen_charge` decimal(8,2) DEFAULT NULL,
  `subtotal` decimal(8,2) DEFAULT NULL,
  `total` decimal(8,2) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_service_booking_id_foreign` (`booking_id`),
  KEY `booking_service_service_id_foreign` (`service_id`),
  KEY `booking_service_service_package_id_foreign` (`service_package_id`),
  CONSTRAINT `booking_service_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `booking_service_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `booking_service_service_package_id_foreign` FOREIGN KEY (`service_package_id`) REFERENCES `service_packages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_service`
--

LOCK TABLES `booking_service` WRITE;
/*!40000 ALTER TABLE `booking_service` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_servicemen`
--

DROP TABLE IF EXISTS `booking_servicemen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_servicemen` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint unsigned DEFAULT NULL,
  `serviceman_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_servicemen_booking_id_foreign` (`booking_id`),
  KEY `booking_servicemen_serviceman_id_foreign` (`serviceman_id`),
  CONSTRAINT `booking_servicemen_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `booking_servicemen_serviceman_id_foreign` FOREIGN KEY (`serviceman_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_servicemen`
--

LOCK TABLES `booking_servicemen` WRITE;
/*!40000 ALTER TABLE `booking_servicemen` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_servicemen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_status`
--

DROP TABLE IF EXISTS `booking_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_status` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sequence` int DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_by_id` bigint unsigned DEFAULT NULL,
  `system_reserve` int NOT NULL DEFAULT '0',
  `hexa_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `booking_status_name_unique` (`name`),
  UNIQUE KEY `booking_status_slug_unique` (`slug`),
  UNIQUE KEY `booking_status_sequence_unique` (`sequence`),
  KEY `booking_status_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `booking_status_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_status`
--

LOCK TABLES `booking_status` WRITE;
/*!40000 ALTER TABLE `booking_status` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_status_logs`
--

DROP TABLE IF EXISTS `booking_status_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_status_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `booking_id` bigint unsigned NOT NULL,
  `booking_status_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_status_logs_booking_id_foreign` (`booking_id`),
  KEY `booking_status_logs_booking_status_id_foreign` (`booking_status_id`),
  CONSTRAINT `booking_status_logs_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `booking_status_logs_booking_status_id_foreign` FOREIGN KEY (`booking_status_id`) REFERENCES `booking_status` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_status_logs`
--

LOCK TABLES `booking_status_logs` WRITE;
/*!40000 ALTER TABLE `booking_status_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_status_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_tax`
--

DROP TABLE IF EXISTS `booking_tax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_tax` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint unsigned NOT NULL,
  `tax_id` bigint unsigned NOT NULL,
  `rate` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_tax_booking_id_foreign` (`booking_id`),
  KEY `booking_tax_tax_id_foreign` (`tax_id`),
  CONSTRAINT `booking_tax_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `booking_tax_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_tax`
--

LOCK TABLES `booking_tax` WRITE;
/*!40000 ALTER TABLE `booking_tax` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_tax` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_transactions`
--

DROP TABLE IF EXISTS `booking_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_transactions_booking_id_foreign` (`booking_id`),
  CONSTRAINT `booking_transactions_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_transactions`
--

LOCK TABLES `booking_transactions` WRITE;
/*!40000 ALTER TABLE `booking_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `video_consultation_id` bigint unsigned DEFAULT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `recurring_booking_id` bigint unsigned DEFAULT NULL,
  `is_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `booking_number` int DEFAULT NULL,
  `consumer_id` bigint unsigned NOT NULL,
  `coupon_id` bigint unsigned DEFAULT NULL,
  `wallet_balance` decimal(8,2) DEFAULT NULL,
  `convert_wallet_balance` double DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  `service_package_id` bigint unsigned DEFAULT NULL,
  `address_id` bigint unsigned DEFAULT NULL,
  `service_price` decimal(8,2) DEFAULT NULL,
  `type` enum('fixed','provider_site','remotely') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed',
  `tax` decimal(8,2) DEFAULT NULL,
  `per_serviceman_charge` decimal(8,2) DEFAULT NULL,
  `coupon_total_discount` decimal(8,2) DEFAULT NULL,
  `platform_fees` decimal(8,2) DEFAULT NULL,
  `platform_fees_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `required_servicemen` int DEFAULT NULL,
  `total_extra_servicemen` int NOT NULL DEFAULT '0',
  `total_servicemen` int DEFAULT NULL,
  `total_extra_servicemen_charge` decimal(8,2) DEFAULT NULL,
  `subtotal` decimal(8,2) DEFAULT NULL,
  `total` decimal(8,2) DEFAULT NULL,
  `advance_payment_amount` decimal(10,2) DEFAULT NULL,
  `remaining_payment_amount` decimal(10,2) DEFAULT NULL,
  `advance_payment_status` enum('PENDING','PAID','REFUNDED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `remaining_payment_status` enum('PENDING','PAID','REFUNDED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `is_advance_payment_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `is_scheduled_booking` tinyint(1) NOT NULL DEFAULT '0',
  `booking_frequency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'daily, weekly, monthly, yearly, custom',
  `schedule_start_date` date DEFAULT NULL,
  `schedule_end_date` date DEFAULT NULL,
  `schedule_time` time DEFAULT NULL,
  `selected_weekdays` json DEFAULT NULL COMMENT 'Array of selected weekdays for daily frequency',
  `scheduled_dates_json` json DEFAULT NULL COMMENT 'JSON array of all scheduled dates and times',
  `scheduled_services_count` int DEFAULT NULL COMMENT 'Total number of scheduled service instances',
  `advance_payment_percentage` decimal(5,2) DEFAULT NULL,
  `transaction_ids` json DEFAULT NULL,
  `date_time` datetime DEFAULT NULL,
  `booking_status_id` bigint unsigned DEFAULT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `description` text COLLATE utf8mb4_unicode_ci,
  `invoice_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` bigint unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bookings_booking_number_unique` (`booking_number`),
  KEY `bookings_consumer_id_foreign` (`consumer_id`),
  KEY `bookings_provider_id_foreign` (`provider_id`),
  KEY `bookings_coupon_id_foreign` (`coupon_id`),
  KEY `bookings_created_by_id_foreign` (`created_by_id`),
  KEY `bookings_address_id_foreign` (`address_id`),
  KEY `bookings_parent_id_foreign` (`parent_id`),
  KEY `bookings_booking_status_id_foreign` (`booking_status_id`),
  KEY `bookings_recurring_booking_id_index` (`recurring_booking_id`),
  KEY `bookings_is_recurring_index` (`is_recurring`),
  KEY `bookings_video_consultation_id_foreign` (`video_consultation_id`),
  CONSTRAINT `bookings_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_booking_status_id_foreign` FOREIGN KEY (`booking_status_id`) REFERENCES `booking_status` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_consumer_id_foreign` FOREIGN KEY (`consumer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_recurring_booking_id_foreign` FOREIGN KEY (`recurring_booking_id`) REFERENCES `recurring_bookings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bookings_video_consultation_id_foreign` FOREIGN KEY (`video_consultation_id`) REFERENCES `video_consultations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `required_servicemen` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  `service_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_time` timestamp NULL DEFAULT NULL,
  `address_id` bigint unsigned DEFAULT NULL,
  `custom_message` longtext COLLATE utf8mb4_unicode_ci,
  `customer_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_service_id_foreign` (`service_id`),
  KEY `cart_address_id_foreign` (`address_id`),
  KEY `cart_customer_id_foreign` (`customer_id`),
  CONSTRAINT `cart_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_servicemen`
--

DROP TABLE IF EXISTS `cart_servicemen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_servicemen` (
  `serviceman_id` bigint unsigned DEFAULT NULL,
  `cart_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  KEY `cart_servicemen_serviceman_id_foreign` (`serviceman_id`),
  KEY `cart_servicemen_cart_id_foreign` (`cart_id`),
  CONSTRAINT `cart_servicemen_cart_id_foreign` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_servicemen_serviceman_id_foreign` FOREIGN KEY (`serviceman_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_servicemen`
--

LOCK TABLES `cart_servicemen` WRITE;
/*!40000 ALTER TABLE `cart_servicemen` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_servicemen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8mb4_unicode_ci,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `parent_id` int DEFAULT NULL,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext COLLATE utf8mb4_unicode_ci,
  `commission` decimal(8,2) DEFAULT '0.00',
  `status` int NOT NULL DEFAULT '0',
  `is_featured` int NOT NULL DEFAULT '0',
  `category_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`),
  KEY `categories_created_by_foreign` (`created_by`),
  CONSTRAINT `categories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (2,'{\"ru\":\"Уборка квартир\"}','uborka-kvartir','{\"ru\":\"Закажите уборку квартиры у проверенного мастера — быстро, предсказуемо, с гарантией. Каждый клинер проходит верификацию по паспорту перед допуском к работе, а стоимость вы видите ещё до оформления заказа: никаких доплат и сюрпризов на месте. Поддерживающая уборка, генеральная или уборка после ремонта — выберите подходящий формат, удобную дату и время. Все заказы застрахованы, а после визита вы оцениваете работу мастера. Платите онлайн, отслеживайте мастера на карте, получайте чистый дом без лишних хлопот.\"}',NULL,NULL,NULL,5.00,1,1,'service',17,'2026-05-28 10:18:10','2026-05-28 10:18:10',NULL),(3,'{\"ru\":\"Уборка офисов и коммерческих помещений\"}','uborka-ofisov-i-kommercheskih-pomeshcheniy','{\"ru\":\"Профессиональная уборка коммерческих помещений для компаний любого масштаба — офисы, кафе, рестораны, коворкинги, шоурумы и салоны. Работаем по договору с полным пакетом закрывающих документов: акты и счета для вашей бухгалтерии. Настройте регулярный график — ежедневно, несколько раз в неделю или разово — и получайте стабильное качество без необходимости держать клинера в штате. Каждый исполнитель верифицирован, каждый выезд застрахован. Прозрачная фиксированная стоимость, оплата онлайн или по безналичному расчёту, персональный менеджер для корпоративных клиентов.\"}',NULL,NULL,NULL,5.00,1,1,'service',17,'2026-05-28 10:18:34','2026-05-28 10:18:34',NULL),(4,'{\"ru\":\"Мастер на час\"}','master-na-chas','{\"ru\":\"Универсальный мастер для любых бытовых задач по дому и в офисе. Повесить полку, карниз или зеркало, установить смеситель, заменить розетку, собрать мебель, починить мелкую неисправность — закажите мастера на час и решите сразу несколько задач за один визит. Стоимость известна заранее, мастер верифицирован по паспорту, работа застрахована. Выбирайте удобное время, отслеживайте прибытие на карте и оценивайте результат. Надёжный помощник для дома — без поиска по объявлениям и торга.\"}',NULL,NULL,NULL,5.00,1,1,'service',17,'2026-05-28 10:18:55','2026-05-28 10:18:55',NULL),(5,'{\"ru\":\"Поддерживающая уборка\"}','podderzhivayushchaya-uborka','{\"ru\":\"1\"}',2,NULL,NULL,5.00,1,1,'service',17,'2026-06-30 09:29:30','2026-06-30 09:29:30',NULL),(6,'{\"ru\":\"Генеральная уборка\"}','generalnaya-uborka','{\"ru\":\"1\"}',2,NULL,NULL,5.00,1,1,'service',17,'2026-06-30 11:04:02','2026-06-30 11:04:02',NULL),(7,'{\"ru\":\"Специальная уборка\"}','specialnaya-uborka','{\"ru\":\"1\"}',2,NULL,NULL,5.00,1,1,'service',17,'2026-06-30 11:04:22','2026-06-30 11:04:22',NULL);
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_zones`
--

DROP TABLE IF EXISTS `category_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_zones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `zone_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_zones_category_id_foreign` (`category_id`),
  KEY `category_zones_zone_id_foreign` (`zone_id`),
  CONSTRAINT `category_zones_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_zones_zone_id_foreign` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_zones`
--

LOCK TABLES `category_zones` WRITE;
/*!40000 ALTER TABLE `category_zones` DISABLE KEYS */;
INSERT INTO `category_zones` VALUES (4,2,1),(5,2,2),(6,2,3),(7,3,1),(8,3,2),(9,3,3),(10,4,1),(11,4,2),(12,4,3),(13,5,1),(14,5,2),(15,5,3),(16,5,6),(17,5,7),(18,2,6),(19,2,7),(20,6,1),(21,6,2),(22,6,3),(23,6,6),(24,6,7),(25,7,1),(26,7,2),(27,7,3),(28,7,6),(29,7,7);
/*!40000 ALTER TABLE `category_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `message` longtext COLLATE utf8mb4_unicode_ci,
  `user_id` bigint unsigned DEFAULT NULL,
  `blog_id` bigint unsigned DEFAULT NULL,
  `parent_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_user_id_foreign` (`user_id`),
  KEY `comments_blog_id_foreign` (`blog_id`),
  CONSTRAINT `comments_blog_id_foreign` FOREIGN KEY (`blog_id`) REFERENCES `blogs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commission_histories`
--

DROP TABLE IF EXISTS `commission_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commission_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `admin_commission` decimal(8,2) DEFAULT '0.00',
  `provider_commission` decimal(8,2) DEFAULT '0.00',
  `booking_id` bigint unsigned DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commission_histories_booking_id_foreign` (`booking_id`),
  KEY `commission_histories_category_id_foreign` (`category_id`),
  KEY `commission_histories_provider_id_foreign` (`provider_id`),
  CONSTRAINT `commission_histories_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commission_histories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `commission_histories_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commission_histories`
--

LOCK TABLES `commission_histories` WRITE;
/*!40000 ALTER TABLE `commission_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` bigint DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `companies_name_unique` (`name`),
  UNIQUE KEY `companies_email_unique` (`email`),
  UNIQUE KEY `companies_phone_unique` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'ComfortCraft','comfort.carft@example.com','123456789',91,'provider company description','2026-05-27 14:39:46','2026-05-27 14:39:46',NULL);
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_symbol` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iso_3166_2` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iso_3166_3` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_code` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_users`
--

DROP TABLE IF EXISTS `coupon_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coupon_users_coupon_id_foreign` (`coupon_id`),
  KEY `coupon_users_user_id_foreign` (`user_id`),
  CONSTRAINT `coupon_users_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_users`
--

LOCK TABLES `coupon_users` WRITE;
/*!40000 ALTER TABLE `coupon_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon_zones`
--

DROP TABLE IF EXISTS `coupon_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon_zones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint unsigned NOT NULL,
  `zone_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coupon_zones_coupon_id_foreign` (`coupon_id`),
  KEY `coupon_zones_zone_id_foreign` (`zone_id`),
  CONSTRAINT `coupon_zones_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coupon_zones_zone_id_foreign` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon_zones`
--

LOCK TABLES `coupon_zones` WRITE;
/*!40000 ALTER TABLE `coupon_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupon_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('fixed','free_service','percentage') COLLATE utf8mb4_unicode_ci DEFAULT 'fixed',
  `amount` decimal(15,2) DEFAULT '0.00',
  `min_spend` decimal(15,2) DEFAULT '0.00',
  `is_unlimited` int DEFAULT '1',
  `usage_per_coupon` int DEFAULT '0',
  `usage_per_customer` int DEFAULT '0',
  `used` int DEFAULT '0',
  `status` int DEFAULT '1',
  `is_expired` int DEFAULT '0',
  `is_apply_all` int DEFAULT '0',
  `is_first_order` int DEFAULT '0',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_by_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coupons_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `coupons_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currencies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `symbol` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `symbol_position` enum('left','right') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'left',
  `no_of_decimal` decimal(8,2) DEFAULT '2.00',
  `exchange_rate` decimal(8,2) DEFAULT '1.00',
  `thousands_separator` enum('comma','period','space') COLLATE utf8mb4_unicode_ci DEFAULT 'comma',
  `decimal_separator` enum('comma','period','space') COLLATE utf8mb4_unicode_ci DEFAULT 'comma',
  `system_reserve` int NOT NULL DEFAULT '0',
  `status` int DEFAULT '1',
  `created_by_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currencies_code_unique` (`code`),
  KEY `currencies_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `currencies_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'RUB','₽','right',2.00,1.00,'comma','comma',0,1,NULL,'2026-05-27 14:38:03','2026-05-27 14:38:03',NULL);
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_ai_models`
--

DROP TABLE IF EXISTS `custom_ai_models`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_ai_models` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `headers` json DEFAULT NULL,
  `params` json DEFAULT NULL,
  `payload` json DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_ai_models`
--

LOCK TABLES `custom_ai_models` WRITE;
/*!40000 ALTER TABLE `custom_ai_models` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_ai_models` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_offers`
--

DROP TABLE IF EXISTS `custom_offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_offers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_servicemen_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_expired` tinyint(1) NOT NULL DEFAULT '0',
  `required_servicemen` int DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `category_ids` json DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `status` enum('pending','accepted','rejected','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `started_at` date DEFAULT NULL,
  `ended_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_offers_provider_id_foreign` (`provider_id`),
  KEY `custom_offers_user_id_foreign` (`user_id`),
  KEY `custom_offers_service_id_foreign` (`service_id`),
  CONSTRAINT `custom_offers_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `custom_offers_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `custom_offers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_offers`
--

LOCK TABLES `custom_offers` WRITE;
/*!40000 ALTER TABLE `custom_offers` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_sms_gateways`
--

DROP TABLE IF EXISTS `custom_sms_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_sms_gateways` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `base_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auth_token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_config` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_keys` json DEFAULT NULL,
  `config` json DEFAULT NULL,
  `body` json DEFAULT NULL,
  `params` json DEFAULT NULL,
  `headers` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_sms_gateways`
--

LOCK TABLES `custom_sms_gateways` WRITE;
/*!40000 ALTER TABLE `custom_sms_gateways` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_sms_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customizations`
--

DROP TABLE IF EXISTS `customizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customizations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `html` longtext COLLATE utf8mb4_unicode_ci,
  `css` longtext COLLATE utf8mb4_unicode_ci,
  `js` longtext COLLATE utf8mb4_unicode_ci,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customizations`
--

LOCK TABLES `customizations` WRITE;
/*!40000 ALTER TABLE `customizations` DISABLE KEYS */;
/*!40000 ALTER TABLE `customizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `is_required` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `button_text` longtext COLLATE utf8mb4_unicode_ci,
  `button_url` longtext COLLATE utf8mb4_unicode_ci,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_templates`
--

LOCK TABLES `email_templates` WRITE;
/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exclude_services_coupons`
--

DROP TABLE IF EXISTS `exclude_services_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exclude_services_coupons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exclude_services_coupons_coupon_id_foreign` (`coupon_id`),
  KEY `exclude_services_coupons_service_id_foreign` (`service_id`),
  CONSTRAINT `exclude_services_coupons_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `exclude_services_coupons_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exclude_services_coupons`
--

LOCK TABLES `exclude_services_coupons` WRITE;
/*!40000 ALTER TABLE `exclude_services_coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `exclude_services_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extra_charges`
--

DROP TABLE IF EXISTS `extra_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extra_charges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_id` bigint unsigned DEFAULT NULL,
  `per_service_amount` decimal(8,2) DEFAULT NULL,
  `no_service_done` int DEFAULT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `tax_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `platform_fees` decimal(10,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `extra_charges_booking_id_foreign` (`booking_id`),
  CONSTRAINT `extra_charges_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extra_charges`
--

LOCK TABLES `extra_charges` WRITE;
/*!40000 ALTER TABLE `extra_charges` DISABLE KEYS */;
/*!40000 ALTER TABLE `extra_charges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favourite_lists`
--

DROP TABLE IF EXISTS `favourite_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favourite_lists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `consumer_id` bigint unsigned NOT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `favourite_lists_consumer_id_foreign` (`consumer_id`),
  KEY `favourite_lists_provider_id_foreign` (`provider_id`),
  KEY `favourite_lists_service_id_foreign` (`service_id`),
  CONSTRAINT `favourite_lists_consumer_id_foreign` FOREIGN KEY (`consumer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `favourite_lists_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `favourite_lists_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favourite_lists`
--

LOCK TABLES `favourite_lists` WRITE;
/*!40000 ALTER TABLE `favourite_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `favourite_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_pages`
--

DROP TABLE IF EXISTS `home_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `home_pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `content` json DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_pages`
--

LOCK TABLES `home_pages` WRITE;
/*!40000 ALTER TABLE `home_pages` DISABLE KEYS */;
INSERT INTO `home_pages` VALUES (1,'{\"en\": {\"download\": {\"title\": \"LaravelCustomer, Provider, Servicemen & Admin application for iOS & Android\", \"points\": [\"Buyers can discover local services in a click.\", \"Buyers can discover local.\", \"Buyers can discover local services.\"], \"status\": true, \"image_url\": \"/frontend/images/gif/app-gif.gif\", \"description\": \"Buyers can discover local services in a click! through our Google Map integration which enhances top level buyer experiences using their GPS locations\"}, \"blogs_list\": {\"title\": \"Latest blog\", \"status\": true, \"blog_ids\": [], \"description\": \"\"}, \"custom_job\": {\"title\": \"Can\'t Find the Right Service? Post a Custom Job Request!\", \"status\": true, \"image_url\": \"/frontend/images/job-request-img.png\", \"button_text\": \"+ Post New Job Request\"}, \"home_banner\": {\"title\": \"One-Stop Solution For Your \", \"status\": true, \"description\": \"We connect you with trusted servicemen for all your home and business needs! 🏠💼 From repairs to installations, we’ve got you covered. 🔧✅ Easy booking, clear pricing, and stress-free service! 😊.\", \"service_ids\": [], \"animate_text\": \"home services\", \"search_enable\": true}, \"news_letter\": {\"title\": \"SUBSCRIBE TO OUR NEWSLETTER\", \"status\": true, \"image_url\": \"/frontend/images/man.png\", \"sub_title\": \"We promise not to spam you.\", \"button_text\": \"Subscribe Now\"}, \"testimonial\": {\"title\": \"What our user have to say about us ?\", \"status\": true}, \"value_banners\": {\"title\": \"Best Valuable Deals\", \"status\": true, \"banners\": [{\"title\": \"Electrical service\", \"status\": true, \"sale_tag\": \"Sale 40%\", \"image_url\": \"/frontend/images/offer/1.png\", \"button_text\": \"Book Now\", \"description\": \"If you want to have stunning look of your house.\", \"redirect_type\": \"service-page\"}, {\"title\": \"Furniture service\", \"status\": true, \"sale_tag\": \"Sale 50%\", \"image_url\": \"/frontend/images/offer/2.png\", \"button_text\": \"Book Now\", \"description\": \"If you want to have stunning look of your house.\", \"redirect_type\": \"category-page\"}, {\"title\": \"Ac cleaning service\", \"status\": true, \"sale_tag\": \"Sale 60%\", \"image_url\": \"/frontend/images/offer/3.png\", \"button_text\": \"Book Now\", \"description\": \"If you want to have stunning look of your house.\", \"redirect_type\": \"service-package-page\"}]}, \"providers_list\": {\"title\": \"Expert provider by rating\", \"status\": true, \"provider_ids\": []}, \"service_list_1\": {\"title\": \"Featured Services\", \"status\": true, \"service_ids\": []}, \"become_a_provider\": {\"title\": \"Earn more and deliver your service to worldwide by become a Service Provider\", \"points\": [\"Buyers can discover local services in a click.\", \"Buyers can discover local.\", \"Buyers can discover local services.\"], \"status\": true, \"image_url\": \"/frontend/images/girl.png\", \"button_url\": \"http://localhost/backend/become-provider\", \"button_text\": \"Register now\", \"description\": \"Buyers can discover local services in a click! through our Google Map integration which.\", \"float_image_1_url\": \"/frontend/images/chart.png\", \"float_image_2_url\": \"/frontend/images/avatars.png\"}, \"categories_icon_list\": {\"title\": \"Top Categories\", \"status\": true, \"category_ids\": []}, \"service_packages_list\": {\"title\": \"Service Packages\", \"status\": true, \"service_packages_ids\": []}, \"special_offers_section\": {\"banner_section_title\": \"Today special offers\", \"service_section_title\": \"Today special offers\"}}}','default',1,'2026-06-14 16:23:05','2026-06-14 16:23:05');
/*!40000 ALTER TABLE `home_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `integration_settings`
--

DROP TABLE IF EXISTS `integration_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `integration_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `type` enum('text','password','toggle','number','select','file') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `group` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `integration_settings_key_unique` (`key`),
  KEY `integration_settings_updated_by_foreign` (`updated_by`),
  CONSTRAINT `integration_settings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integration_settings`
--

LOCK TABLES `integration_settings` WRITE;
/*!40000 ALTER TABLE `integration_settings` DISABLE KEYS */;
INSERT INTO `integration_settings` VALUES (1,'onboarding_mock_mode','1','toggle','general','Режим Mock (Sprint 1)',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(2,'onboarding_enabled','1','toggle','general','Онбординг включён',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(3,'dadata_api_key','eyJpdiI6IkphVEdDRVFOVjVQQ09UaExaWVRCaWc9PSIsInZhbHVlIjoieXVpd0JLanlxUWk2N1AwYVpJYTFHV1VGeFg4ZDBDM2NQVk1QVlFOQmF2Qm1ucGVPNUVBc1hpdXdyL2NsSW5adlB4NFhONzFUdEhhbTJpeTBpZVpoUXc9PSIsIm1hYyI6IjdjNzg2ODJiOTY4YjEyMGE1MmQwNWZhODhjZjBiMjE4YjhiZTY3M2UxM2I1MDZjOGExYmEyMTNkMTVlMDRhNGIiLCJ0YWciOiIifQ==','password','fns','DaData API Key',17,'2026-05-27 15:12:32','2026-05-27 15:21:26'),(4,'dadata_secret_key','eyJpdiI6ImZHSVpmSElnS0pjOXpsRHRwUkpvRmc9PSIsInZhbHVlIjoiNjNVdTZWUW1UNnhGRkpKbFVXR3cyTS9GWFNvb2R1Ti8xY0xScWhmejlrV2VnSmxGVUVjRlRVbTdVVEtEZW1wc1drZ3FOZXhIZVJEeHBKcXhFelZZTnc9PSIsIm1hYyI6ImNkZDIxZTNhNmQ5NDdmNzk4YzVkZDg4ODg3NDg0MjhjNDMzNzdlYTM1ZTA1ZDAyMmZmZGJhMGMzMmI0NmQ4NWQiLCJ0YWciOiIifQ==','password','fns','DaData Secret Key',17,'2026-05-27 15:12:32','2026-05-27 15:21:26'),(5,'passport_provider','manual','select','passport','Провайдер верификации паспорта',17,'2026-05-27 15:12:32','2026-05-27 15:12:54'),(6,'passport_api_key',NULL,'password','passport','API Key (Суфтех / Контур)',NULL,'2026-05-27 15:12:32','2026-05-27 15:12:32'),(7,'passport_endpoint','','text','passport','Endpoint URL',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(8,'telegram_bot_token',NULL,'password','passport','Telegram Bot Token',NULL,'2026-05-27 15:12:32','2026-05-27 15:12:32'),(9,'telegram_admin_chat_id','','text','passport','Telegram Admin Chat ID',17,'2026-05-27 15:12:32','2026-05-27 15:12:54'),(10,'fssp_provider','manual','select','fssp','Провайдер ФССП',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(11,'fssp_api_key',NULL,'password','fssp','API Key (Контур / SmartDeal)',NULL,'2026-05-27 15:12:32','2026-05-27 15:12:32'),(12,'fssp_debt_threshold','10000','number','fssp','Порог долга для блокировки (руб.)',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(13,'contract_company_name','','text','contract','Наименование компании в договоре',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(14,'contract_company_inn','','text','contract','ИНН компании',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(15,'contract_director','','text','contract','ФИО директора',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(16,'contract_version_self_employed','1','number','contract','Версия договора: Самозанятый',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(17,'contract_version_ip','1','number','contract','Версия договора: ИП',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(18,'contract_version_ooo','1','number','contract','Версия договора: ООО',17,'2026-05-27 15:12:32','2026-05-27 15:12:53'),(19,'contract_version_gph','1','number','contract','Версия договора: ГПХ',17,'2026-05-27 15:12:32','2026-05-27 15:12:53');
/*!40000 ALTER TABLE `integration_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `languages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'Afrikaans','Afrikaans',NULL,NULL),(2,'English','English',NULL,NULL),(3,'Albanian','Albanian',NULL,NULL),(4,'Amharic','Amharic',NULL,NULL),(5,'Arabic','Arabic',NULL,NULL),(6,'Armenian','Armenian',NULL,NULL),(7,'Azerbaijani','Azerbaijani',NULL,NULL),(8,'Basque','Basque',NULL,NULL),(9,'Belarusian','Belarusian',NULL,NULL),(10,'Bengali','Bengali',NULL,NULL),(11,'Bosnian','Bosnian',NULL,NULL),(12,'Bulgarian','Bulgarian',NULL,NULL),(13,'Catalan','Catalan',NULL,NULL),(14,'Cebuano','Cebuano',NULL,NULL),(15,'Chichewa','Chichewa',NULL,NULL),(16,'Chinese','Chinese',NULL,NULL),(17,'Corsican','Corsican',NULL,NULL),(18,'Croatian','Croatian',NULL,NULL),(19,'Czech','Czech',NULL,NULL),(20,'Danish','Danish',NULL,NULL),(21,'Dutch','Dutch',NULL,NULL),(22,'Esperanto','Esperanto',NULL,NULL),(23,'Estonian','Estonian',NULL,NULL),(24,'Filipino','Filipino',NULL,NULL),(25,'Finnish','Finnish',NULL,NULL),(26,'French','French',NULL,NULL),(27,'Frisian','Frisian',NULL,NULL),(28,'Galician','Galician',NULL,NULL),(29,'Georgian','Georgian',NULL,NULL),(30,'German','German',NULL,NULL),(31,'Greek','Greek',NULL,NULL),(32,'Gujarati','Gujarati',NULL,NULL),(33,'Haitian Creole','Haitian Creole',NULL,NULL),(34,'Hausa','Hausa',NULL,NULL),(35,'Hawaiian','Hawaiian',NULL,NULL),(36,'Hebrew','Hebrew',NULL,NULL),(37,'Hindi','Hindi',NULL,NULL),(38,'Hmong','Hmong',NULL,NULL),(39,'Hungarian','Hungarian',NULL,NULL),(40,'Icelandic','Icelandic',NULL,NULL),(41,'Igbo','Igbo',NULL,NULL),(42,'Indonesian','Indonesian',NULL,NULL),(43,'Irish','Irish',NULL,NULL),(44,'Italian','Italian',NULL,NULL),(45,'Japanese','Japanese',NULL,NULL),(46,'Javanese','Javanese',NULL,NULL),(47,'Kannada','Kannada',NULL,NULL),(48,'Kazakh','Kazakh',NULL,NULL),(49,'Khmer','Khmer',NULL,NULL),(50,'Kinyarwanda','Kinyarwanda',NULL,NULL),(51,'Korean','Korean',NULL,NULL),(52,'Kurdish','Kurdish',NULL,NULL),(53,'Kyrgyz','Kyrgyz',NULL,NULL),(54,'Lao','Lao',NULL,NULL),(55,'Latin','Latin',NULL,NULL),(56,'Latvian','Latvian',NULL,NULL),(57,'Lithuanian','Lithuanian',NULL,NULL),(58,'Luxembourgish','Luxembourgish',NULL,NULL),(59,'Macedonian','Macedonian',NULL,NULL),(60,'Malagasy','Malagasy',NULL,NULL),(61,'Malay','Malay',NULL,NULL),(62,'Malayalam','Malayalam',NULL,NULL),(63,'Maltese','Maltese',NULL,NULL),(64,'Maori','Maori',NULL,NULL),(65,'Marathi','Marathi',NULL,NULL),(66,'Mongolian','Mongolian',NULL,NULL),(67,'Burmese','Burmese',NULL,NULL),(68,'Nepali','Nepali',NULL,NULL),(69,'Norwegian','Norwegian',NULL,NULL),(70,'Odia','Odia',NULL,NULL),(71,'Pashto','Pashto',NULL,NULL),(72,'Persian','Persian',NULL,NULL),(73,'Polish','Polish',NULL,NULL),(74,'Portuguese','Portuguese',NULL,NULL),(75,'Punjabi','Punjabi',NULL,NULL),(76,'Romanian','Romanian',NULL,NULL),(77,'Russian','Russian',NULL,NULL),(78,'Samoan','Samoan',NULL,NULL),(79,'Scots Gaelic','Scots Gaelic',NULL,NULL),(80,'Serbian','Serbian',NULL,NULL),(81,'Sesotho','Sesotho',NULL,NULL),(82,'Shona','Shona',NULL,NULL),(83,'Sindhi','Sindhi',NULL,NULL),(84,'Sinhala','Sinhala',NULL,NULL),(85,'Slovak','Slovak',NULL,NULL),(86,'Slovenian','Slovenian',NULL,NULL),(87,'Somali','Somali',NULL,NULL),(88,'Spanish','Spanish',NULL,NULL),(89,'Sundanese','Sundanese',NULL,NULL),(90,'Swahili','Swahili',NULL,NULL),(91,'Swedish','Swedish',NULL,NULL),(92,'Tajik','Tajik',NULL,NULL),(93,'Tamil','Tamil',NULL,NULL),(94,'Telugu','Telugu',NULL,NULL),(95,'Thai','Thai',NULL,NULL),(96,'Turkish','Turkish',NULL,NULL),(97,'Ukrainian','Ukrainian',NULL,NULL),(98,'Urdu','Urdu',NULL,NULL),(99,'Uyghur','Uyghur',NULL,NULL),(100,'Uzbek','Uzbek',NULL,NULL),(101,'Vietnamese','Vietnamese',NULL,NULL),(102,'Welsh','Welsh',NULL,NULL),(103,'Xhosa','Xhosa',NULL,NULL),(104,'Yiddish','Yiddish',NULL,NULL),(105,'Yoruba','Yoruba',NULL,NULL),(106,'Zulu','Zulu',NULL,NULL),(107,'Tsonga','Tsonga',NULL,NULL);
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locals`
--

DROP TABLE IF EXISTS `locals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rtl` int DEFAULT '0',
  `status` int DEFAULT '1',
  `system_reserve` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locals`
--

LOCK TABLES `locals` WRITE;
/*!40000 ALTER TABLE `locals` DISABLE KEYS */;
/*!40000 ALTER TABLE `locals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `media`
--

DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `media` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint unsigned NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `generated_conversions` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `media_order_column_index` (`order_column`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `media`
--

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT INTO `media` VALUES (3,'App\\Models\\Category',5,'ae8fd71a-2ac5-410e-8249-3345cd21c9f6','image','Gemini_Generated_Image_esajwcesajwcesaj','Gemini_Generated_Image_esajwcesajwcesaj.png','image/png','public','public',1999429,'[]','{\"language\": \"ru\"}','[]','[]',1,'2026-06-30 11:06:16','2026-06-30 11:06:16'),(4,'App\\Models\\Service',2,'c57d13f8-c859-46a8-912b-2f9a2af4ce57','image','Gemini_Generated_Image_kwrqukkwrqukkwrq','Gemini_Generated_Image_kwrqukkwrqukkwrq.png','image/png','public','public',1988200,'[]','{\"language\": \"ru\"}','[]','[]',2,'2026-06-30 11:14:41','2026-06-30 11:14:41'),(5,'App\\Models\\Service',2,'003ec95d-5870-46e0-90c8-8aad307c885f','thumbnail','Gemini_Generated_Image_kwrqukkwrqukkwrq','Gemini_Generated_Image_kwrqukkwrqukkwrq.png','image/png','public','public',1988200,'[]','{\"language\": \"ru\"}','[]','[]',3,'2026-06-30 11:14:41','2026-06-30 11:14:41'),(6,'App\\Models\\Service',2,'cdcccd90-7419-439a-9315-796185f016d2','web_images','Gemini_Generated_Image_kwrqukkwrqukkwrq','Gemini_Generated_Image_kwrqukkwrqukkwrq.png','image/png','public','public',1988200,'[]','{\"language\": \"ru\"}','[]','[]',4,'2026-06-30 11:14:41','2026-06-30 11:14:41'),(7,'App\\Models\\Service',2,'1cc36f32-1437-4a75-9321-a1ca1433c98f','web_thumbnail','Gemini_Generated_Image_kwrqukkwrqukkwrq','Gemini_Generated_Image_kwrqukkwrqukkwrq.png','image/png','public','public',1988200,'[]','{\"language\": \"ru\"}','[]','[]',5,'2026-06-30 11:14:41','2026-06-30 11:14:41'),(8,'App\\Models\\Service',1,'93422313-6901-4114-aa5c-51bdaa351473','image','Gemini_Generated_Image_dsbjzdsbjzdsbjzd','Gemini_Generated_Image_dsbjzdsbjzdsbjzd.png','image/png','public','public',1982722,'[]','{\"language\": \"ru\"}','[]','[]',2,'2026-06-30 11:14:56','2026-06-30 11:14:56'),(9,'App\\Models\\Service',1,'209667dc-a798-4bbb-ba3f-4ac109252279','thumbnail','Gemini_Generated_Image_dsbjzdsbjzdsbjzd','Gemini_Generated_Image_dsbjzdsbjzdsbjzd.png','image/png','public','public',1982722,'[]','{\"language\": \"ru\"}','[]','[]',3,'2026-06-30 11:14:56','2026-06-30 11:14:56'),(10,'App\\Models\\Service',1,'9dccd56c-6f10-429c-8fad-8bdc8e86785c','web_images','Gemini_Generated_Image_dsbjzdsbjzdsbjzd','Gemini_Generated_Image_dsbjzdsbjzdsbjzd.png','image/png','public','public',1982722,'[]','{\"language\": \"ru\"}','[]','[]',4,'2026-06-30 11:14:56','2026-06-30 11:14:56'),(11,'App\\Models\\Service',1,'b6531ce3-dafe-481e-9e2c-6899347bda1e','web_thumbnail','Gemini_Generated_Image_dsbjzdsbjzdsbjzd','Gemini_Generated_Image_dsbjzdsbjzdsbjzd.png','image/png','public','public',1982722,'[]','{\"language\": \"ru\"}','[]','[]',5,'2026-06-30 11:14:56','2026-06-30 11:14:56');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_04_24_050852_create_seeders_table',1),(6,'2023_06_19_085426_create_media_table',1),(7,'2023_06_27_135121_create_permission_tables',1),(8,'2023_06_29_080345_create_taxes_table',1),(9,'2023_07_05_065133_setup_countries_table',1),(10,'2023_07_08_102424_create_currencies_table',1),(11,'2023_07_09_065210_create_banners_table',1),(12,'2023_07_09_065211_create_zones_table',1),(13,'2023_07_09_065212_create_advertisements_table',1),(14,'2023_07_10_043819_create_category_table',1),(15,'2023_07_19_122313_create_documents_table',1),(16,'2023_07_22_091302_create_user_documents_table',1),(17,'2023_07_24_055205_create_coupons_table',1),(18,'2023_07_26_055206_create_services_table',1),(19,'2023_07_29_090254_create_addresses_table',1),(20,'2023_08_24_081526_create_service_packages_table',1),(21,'2023_08_26_091958_create_blogs_table',1),(22,'2023_08_28_092234_create_tags_table',1),(23,'2023_08_29_123904_create_bookings_table',1),(24,'2023_09_02_065555_create_time_slots_table',1),(25,'2023_09_08_134429_create_wallets_table',1),(26,'2023_09_12_093347_create_settings_table',1),(27,'2023_09_13_044525_create_time_zones_table',1),(28,'2023_09_16_051532_create_favourite_lists_table',1),(29,'2023_09_30_060752_create_pages_table',1),(30,'2023_10_06_041035_create_rating_table',1),(31,'2023_10_06_062104_create_reviews_table',1),(32,'2023_10_26_110014_create_languages_table',1),(33,'2023_10_26_121530_create_user_expertise_services_table',1),(34,'2023_10_31_084153_create_companies_table',1),(35,'2023_10_31_141434_create_bank_details_table',1),(36,'2023_11_07_110855_create_notifications_table',1),(37,'2023_11_18_133437_create_provider_wallets_table',1),(38,'2023_11_18_134114_create_provider_transactions_table',1),(39,'2023_12_05_062849_create_payment_gateways_table',1),(40,'2023_12_11_135826_create_booking_reason_logs_table',1),(41,'2023_12_12_132218_create_booking_status_logs_table',1),(42,'2023_12_12_132218_create_testimonials_table',1),(43,'2023_12_28_055631_add_column_to_addresses_table',1),(44,'2023_12_28_122944_add_column_to_users_table',1),(45,'2023_12_30_054108_create_service_availabilities_table',1),(46,'2023_12_30_055849_create_service_address_table',1),(47,'2024_01_08_110422_create_commission_histories_table',1),(48,'2024_01_23_095945_create_plans_table',1),(49,'2024_01_23_112804_create_user_subscriptions_table',1),(50,'2024_01_30_174650_create_jobs_table',1),(51,'2024_01_31_160601_create_withdraw_requests_table',1),(52,'2024_02_12_150305_create_locals_table',1),(53,'2024_04_13_142107_create_service_proofs_table',1),(54,'2024_04_19_172431_create_extra_charges_table',1),(55,'2024_05_20_105814_create_service_faqs_table',1),(56,'2024_05_24_115130_create_push_notifications_table',1),(57,'2024_05_31_045337_create_system_langs_table',1),(58,'2024_08_15_152729_create_serviceman_commissions_table',1),(59,'2024_08_26_151520_create_home_page_table',1),(60,'2024_08_26_151520_create_theme_options_table copy',1),(61,'2024_09_16_112032_create_service_requests_table',1),(62,'2024_10_10_101746_banner_zones',1),(63,'2024_10_11_120824_create_subscribes_table',1),(64,'2024_10_12_083722_create_email_templates',1),(65,'2024_10_14_111617_create_sms_templates',1),(66,'2024_10_14_153607_add_tables_related_to_coupon',1),(67,'2024_10_15_041531_create_push_notification_templates',1),(68,'2024_10_18_142746_create_comments_table',1),(69,'2024_10_18_184753_add_column_to_services_table',1),(70,'2024_10_23_155739_custom_sms_gateways',1),(71,'2024_10_29_152925_add_column_to_users_table',1),(72,'2024_11_03_191340_create_seo_table',1),(73,'2024_11_27_054315_create_backup_logs',1),(74,'2024_12_13_120733_create_custom_offers_table',1),(75,'2024_12_16_035102_create_customizations_table',1),(76,'2024_12_20_000002_create_recurring_bookings_table',1),(77,'2024_12_20_000003_add_recurring_booking_id_to_bookings_table',1),(78,'2024_12_20_000004_add_is_recurring_to_bookings_table',1),(79,'2025_01_15_000000_add_advance_payment_columns_to_services_table',1),(80,'2025_02_27_142812_create_activity_log_table',1),(81,'2025_02_27_142813_add_event_column_to_activity_log_table',1),(82,'2025_02_27_142814_add_batch_uuid_column_to_activity_log_table',1),(83,'2025_03_22_110349_create_cart_table',1),(84,'2025_06_09_130214_add_is_custom_offer_to_services_table',1),(85,'2025_06_14_121340_add_app_type_to_pages_table',1),(86,'2025_07_03_183525_add_symbol_position_to_currencies_table',1),(87,'2025_07_09_201103_create_booking_tax_table',1),(88,'2025_07_11_174159_add_zone_id_to_taxes_table',1),(89,'2025_07_11_195635_add_tax_and_platform_fees_to_extra_charges_table',1),(90,'2025_08_11_103715_create_video_consultations_table',1),(91,'2025_08_11_133421_add_video_consultation_id_to_bookings_table',1),(92,'2025_11_21_122814_add_referral_columns_to_users_table',1),(93,'2025_11_21_140945_create_cache_table',1),(94,'2025_11_24_151357_create_referral_bonuses_table',1),(95,'2025_12_08_180257_create_wallet_bonuses_table',1),(96,'2025_12_09_120218_add_columns_to_transactions_table',1),(97,'2025_12_21_145858_create_seo_settings_table',1),(98,'2025_12_30_142506_create_custom_ai_models_table',1),(99,'2026_01_06_175504_add_usage_limits',1),(100,'2026_01_12_165214_add_advance_payment_fields_to_bookings_table',1),(101,'2026_01_12_165216_create_booking_payment_transactions_pivot_table',1),(102,'2026_01_12_181716_create_messages_table',1),(103,'2026_01_15_000000_create_user_zone_permissions_table',1),(104,'2026_01_15_000001_add_allow_all_zones_to_users_table',1),(105,'2026_01_18_234026_add_scheduled_booking_fields_to_bookings_table',1),(106,'2026_05_25_000001_alter_users_add_onboarding',1),(107,'2026_05_25_000002_create_integration_settings_table',1),(108,'2026_05_25_000003_create_provider_verifications_table',1),(109,'2026_05_25_000004_create_onboarding_logs_table',1),(110,'2026_05_26_000001_remove_platru_integration_settings',1),(111,'2026_05_26_000002_alter_provider_verifications_sprint2',1),(112,'2026_06_30_131806_add_video_to_services_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',17),(2,'App\\Models\\User',18),(3,'App\\Models\\User',19),(1,'App\\Models\\User',20),(4,'App\\Models\\User',21);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actions` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,'roles','{\"index\":\"backend.role.index\",\"create\":\"backend.role.create\",\"edit\":\"backend.role.edit\",\"destroy\":\"backend.role.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(2,'bank_details','{\"index\":\"backend.bank_detail.index\",\"create\":\"backend.bank_detail.create\",\"edit\":\"backend.bank_detail.edit\",\"destroy\":\"backend.bank_detail.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(3,'service_categories','{\"index\":\"backend.service_category.index\",\"create\":\"backend.service_category.create\",\"edit\":\"backend.service_category.edit\",\"destroy\":\"backend.service_category.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(4,'blog_categories','{\"index\":\"backend.blog_category.index\",\"create\":\"backend.blog_category.create\",\"edit\":\"backend.blog_category.edit\",\"destroy\":\"backend.blog_category.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(5,'services','{\"index\":\"backend.service.index\",\"create\":\"backend.service.create\",\"edit\":\"backend.service.edit\",\"destroy\":\"backend.service.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(6,'plans','{\"index\":\"backend.plan.index\",\"create\":\"backend.plan.create\",\"edit\":\"backend.plan.edit\",\"destroy\":\"backend.plan.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(7,'service_packages','{\"index\":\"backend.service-package.index\",\"create\":\"backend.service-package.create\",\"edit\":\"backend.service-package.edit\",\"destroy\":\"backend.service-package.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(8,'bookings','{\"index\":\"backend.booking.index\",\"create\":\"backend.booking.create\",\"edit\":\"backend.booking.edit\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(9,'custom_offers','{\"index\":\"backend.custom_offer.index\",\"create\":\"backend.custom_offer.create\",\"edit\":\"backend.custom_offer.edit\",\"destroy\":\"backend.custom_offer.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(10,'providers','{\"index\":\"backend.provider.index\",\"create\":\"backend.provider.create\",\"edit\":\"backend.provider.edit\",\"destroy\":\"backend.provider.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(11,'provider_wallets','{\"index\":\"backend.provider_wallet.index\",\"credit\":\"backend.provider_wallet.credit\",\"debit\":\"backend.provider_wallet.debit\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(12,'serviceman_wallets','{\"index\":\"backend.serviceman_wallet.index\",\"credit\":\"backend.serviceman_wallet.credit\",\"debit\":\"backend.serviceman_wallet.debit\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(13,'commission_histories','{\"index\":\"backend.commission_history.index\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(14,'withdraw_requests','{\"index\":\"backend.withdraw_request.index\",\"create\":\"backend.withdraw_request.create\",\"action\":\"backend.withdraw_request.action\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(15,'serviceman_withdraw_requests','{\"index\":\"backend.serviceman_withdraw_request.index\",\"create\":\"backend.serviceman_withdraw_request.create\",\"action\":\"backend.serviceman_withdraw_request.action\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(16,'servicemen','{\"index\":\"backend.serviceman.index\",\"create\":\"backend.serviceman.create\",\"edit\":\"backend.serviceman.edit\",\"destroy\":\"backend.serviceman.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(17,'coupons','{\"index\":\"backend.coupon.index\",\"create\":\"backend.coupon.create\",\"edit\":\"backend.coupon.edit\",\"destroy\":\"backend.coupon.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(18,'backups','{\"index\":\"backend.backup.index\",\"create\":\"backend.backup.create\",\"edit\":\"backend.backup.edit\",\"trash\":\"backend.backup.destroy\"}','2026-05-27 14:39:42','2026-05-27 14:39:42'),(19,'system_tools','{\"index\":\"backend.system_tool.index\",\"create\":\"backend.system_tool.create\",\"edit\":\"backend.system_tool.edit\",\"trash\":\"backend.system_tool.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(20,'wallets','{\"index\":\"backend.wallet.index\",\"credit\":\"backend.wallet.credit\",\"debit\":\"backend.wallet.debit\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(21,'sliders','{\"index\":\"backend.slider.index\",\"create\":\"backend.slider.create\",\"edit\":\"backend.slider.edit\",\"destroy\":\"backend.slider.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(22,'reviews','{\"index\":\"backend.review.index\",\"create\":\"backend.review.create\",\"edit\":\"backend.review.edit\",\"destroy\":\"backend.review.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(23,'earnings','{\"index\":\"backend.earning.index\",\"create\":\"backend.earning.create\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(24,'taxes','{\"index\":\"backend.tax.index\",\"create\":\"backend.tax.create\",\"edit\":\"backend.tax.edit\",\"destroy\":\"backend.tax.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(25,'users','{\"index\":\"backend.user.index\",\"create\":\"backend.user.create\",\"edit\":\"backend.user.edit\",\"destroy\":\"backend.user.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(26,'zone_managers','{\"index\":\"backend.zone_manager.index\",\"create\":\"backend.zone_manager.create\",\"edit\":\"backend.zone_manager.edit\",\"destroy\":\"backend.zone_manager.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(27,'customers','{\"index\":\"backend.customer.index\",\"create\":\"backend.customer.create\",\"edit\":\"backend.customer.edit\",\"destroy\":\"backend.customer.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(28,'payment_transactions','{\"index\":\"backend.payment_transaction.index\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(29,'documents','{\"index\":\"backend.document.index\",\"create\":\"backend.document.create\",\"edit\":\"backend.document.edit\",\"destroy\":\"backend.document.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(30,'currencies','{\"index\":\"backend.currency.index\",\"create\":\"backend.currency.create\",\"edit\":\"backend.currency.edit\",\"destroy\":\"backend.currency.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(31,'tags','{\"index\":\"backend.tag.index\",\"create\":\"backend.tag.create\",\"edit\":\"backend.tag.edit\",\"destroy\":\"backend.tag.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(32,'blogs','{\"index\":\"backend.blog.index\",\"create\":\"backend.blog.create\",\"edit\":\"backend.blog.edit\",\"destroy\":\"backend.blog.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(33,'pages','{\"index\":\"backend.page.index\",\"create\":\"backend.page.create\",\"edit\":\"backend.page.edit\",\"destroy\":\"backend.page.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(34,'provider_time_slots','{\"index\":\"backend.provider_time_slot.index\",\"create\":\"backend.provider_time_slot.create\",\"edit\":\"backend.provider_time_slot.edit\",\"destroy\":\"backend.provider_time_slot.destroy\"}','2026-05-27 14:39:43','2026-05-27 14:39:43'),(35,'provider_documents','{\"index\":\"backend.provider_document.index\",\"create\":\"backend.provider_document.create\",\"edit\":\"backend.provider_document.edit\",\"destroy\":\"backend.provider_document.destroy\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(36,'serviceman_documents','{\"index\":\"backend.serviceman_document.index\",\"create\":\"backend.serviceman_document.create\",\"edit\":\"backend.serviceman_document.edit\",\"destroy\":\"backend.serviceman_document.destroy\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(37,'banners','{\"index\":\"backend.banner.index\",\"create\":\"backend.banner.create\",\"edit\":\"backend.banner.edit\",\"destroy\":\"backend.banner.destroy\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(38,'advertisements','{\"index\":\"backend.advertisement.index\",\"create\":\"backend.advertisement.create\",\"edit\":\"backend.advertisement.edit\",\"destroy\":\"backend.advertisement.destroy\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(39,'settings','{\"index\":\"backend.setting.index\",\"create\":\"backend.setting.create\",\"edit\":\"backend.setting.edit\",\"destroy\":\"backend.setting.destroy\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(40,'payment_methods','{\"index\":\"backend.payment_method.index\",\"create\":\"backend.payment_method.create\",\"edit\":\"backend.payment_method.edit\",\"destroy\":\"backend.payment_method.destroy\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(41,'sms_gateways','{\"index\":\"backend.sms_gateway.index\",\"edit\":\"backend.sms_gateway.edit\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(42,'languages','{\"index\":\"backend.language.index\",\"create\":\"backend.language.create\",\"edit\":\"backend.language.edit\",\"destroy\":\"backend.language.destroy\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(43,'push_notifications','{\"index\":\"backend.push_notification.index\",\"create\":\"backend.push_notification.create\",\"edit\":\"backend.push_notification.edit\",\"destroy\":\"backend.push_notification.destroy\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(44,'bids','{\"index\":\"backend.bid.index\",\"create\":\"backend.bid.create\",\"edit\":\"backend.bid.edit\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(45,'zones','{\"index\":\"backend.zone.index\",\"create\":\"backend.zone.create\",\"edit\":\"backend.zone.edit\",\"destroy\":\"backend.zone.destroy\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(46,'home_pages','{\"index\":\"backend.home_page.index\",\"edit\":\"backend.home_page.edit\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(47,'customizations','{\"index\":\"backend.customization.index\",\"edit\":\"backend.customization.edit\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(48,'testimonials','{\"index\":\"backend.testimonial.index\",\"create\":\"backend.testimonial.create\",\"edit\":\"backend.testimonial.edit\",\"destroy\":\"backend.testimonial.destroy\"}','2026-05-27 14:39:44','2026-05-27 14:39:44'),(49,'theme_options','{\"index\":\"backend.theme_option.index\",\"edit\":\"backend.theme_option.edit\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(50,'news_letters','{\"index\":\"backend.news_letter.index\",\"create\":\"backend.news_letter.create\",\"edit\":\"backend.news_letter.edit\",\"destroy\":\"backend.news_letter.destroy\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(51,'sms_templates','{\"index\":\"backend.sms_template.index\",\"edit\":\"backend.sms_template.edit\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(52,'email_templates','{\"index\":\"backend.email_template.index\",\"edit\":\"backend.email_template.edit\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(53,'push_notification_templates','{\"index\":\"backend.push_notification_template.index\",\"edit\":\"backend.push_notification_template.edit\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(54,'service_request','{\"index\":\"backend.service_request.index\",\"create\":\"backend.service_request.create\",\"edit\":\"backend.service_request.edit\",\"destroy\":\"backend.service_request.destroy\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(55,'custom_sms_gateways','{\"index\":\"backend.custom_sms_gateway.index\",\"edit\":\"backend.custom_sms_gateway.edit\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(56,'provider_dashboard','{\"index\":\"backend.provider_dashboard.index\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(57,'consumer_dashboard','{\"index\":\"backend.consumer_dashboard.index\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(58,'servicemen_dashboard','{\"index\":\"backend.servicemen_dashboard.index\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(59,'unverified_user','{\"index\":\"backend.unverified_user.index\",\"edit\":\"backend.unverified_user.edit\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(60,'serviceman_locations','{\"index\":\"backend.serviceman_location.index\",\"create\":\"backend.serviceman_location.create\",\"edit\":\"backend.serviceman_location.edit\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(61,'reports','{\"index\":\"backend.report.index\",\"create\":\"backend.report.create\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(62,'referrals','{\"index\":\"backend.referral.index\",\"create\":\"backend.referral.create\",\"edit\":\"backend.referral.edit\",\"destroy\":\"backend.referral.destroy\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(63,'chats','{\"index\":\"backend.chat.index\",\"send\":\"backend.chat.send\",\"reply\":\"backend.chat.replay\",\"destroy\":\"backend.chat.destroy\"}','2026-05-27 14:39:45','2026-05-27 14:39:45'),(64,'wallet_bonuses','{\"index\":\"backend.wallet_bonus.index\",\"send\":\"backend.wallet_bonus.send\",\"reply\":\"backend.wallet_bonus.replay\",\"destroy\":\"backend.wallet_bonus.destroy\"}','2026-05-27 14:39:46','2026-05-27 14:39:46'),(65,'seo_settings','{\"index\":\"backend.seo_setting.index\",\"create\":\"backend.seo_setting.create\",\"edit\":\"backend.seo_setting.edit\",\"destroy\":\"backend.seo_setting.destroy\"}','2026-05-27 14:39:46','2026-05-27 14:39:46'),(66,'custom_ai_model','{\"index\":\"backend.custom_ai_model.index\",\"create\":\"backend.custom_ai_model.create\",\"edit\":\"backend.custom_ai_model.edit\",\"destroy\":\"backend.custom_ai_model.destroy\"}','2026-05-27 14:39:46','2026-05-27 14:39:46'),(67,'roles','{\"index\":\"backend.role.index\",\"create\":\"backend.role.create\",\"edit\":\"backend.role.edit\",\"destroy\":\"backend.role.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(68,'bank_details','{\"index\":\"backend.bank_detail.index\",\"create\":\"backend.bank_detail.create\",\"edit\":\"backend.bank_detail.edit\",\"destroy\":\"backend.bank_detail.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(69,'service_categories','{\"index\":\"backend.service_category.index\",\"create\":\"backend.service_category.create\",\"edit\":\"backend.service_category.edit\",\"destroy\":\"backend.service_category.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(70,'blog_categories','{\"index\":\"backend.blog_category.index\",\"create\":\"backend.blog_category.create\",\"edit\":\"backend.blog_category.edit\",\"destroy\":\"backend.blog_category.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(71,'services','{\"index\":\"backend.service.index\",\"create\":\"backend.service.create\",\"edit\":\"backend.service.edit\",\"destroy\":\"backend.service.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(72,'plans','{\"index\":\"backend.plan.index\",\"create\":\"backend.plan.create\",\"edit\":\"backend.plan.edit\",\"destroy\":\"backend.plan.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(73,'service_packages','{\"index\":\"backend.service-package.index\",\"create\":\"backend.service-package.create\",\"edit\":\"backend.service-package.edit\",\"destroy\":\"backend.service-package.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(74,'bookings','{\"index\":\"backend.booking.index\",\"create\":\"backend.booking.create\",\"edit\":\"backend.booking.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(75,'custom_offers','{\"index\":\"backend.custom_offer.index\",\"create\":\"backend.custom_offer.create\",\"edit\":\"backend.custom_offer.edit\",\"destroy\":\"backend.custom_offer.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(76,'providers','{\"index\":\"backend.provider.index\",\"create\":\"backend.provider.create\",\"edit\":\"backend.provider.edit\",\"destroy\":\"backend.provider.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(77,'provider_wallets','{\"index\":\"backend.provider_wallet.index\",\"credit\":\"backend.provider_wallet.credit\",\"debit\":\"backend.provider_wallet.debit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(78,'serviceman_wallets','{\"index\":\"backend.serviceman_wallet.index\",\"credit\":\"backend.serviceman_wallet.credit\",\"debit\":\"backend.serviceman_wallet.debit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(79,'commission_histories','{\"index\":\"backend.commission_history.index\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(80,'withdraw_requests','{\"index\":\"backend.withdraw_request.index\",\"create\":\"backend.withdraw_request.create\",\"action\":\"backend.withdraw_request.action\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(81,'serviceman_withdraw_requests','{\"index\":\"backend.serviceman_withdraw_request.index\",\"create\":\"backend.serviceman_withdraw_request.create\",\"action\":\"backend.serviceman_withdraw_request.action\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(82,'servicemen','{\"index\":\"backend.serviceman.index\",\"create\":\"backend.serviceman.create\",\"edit\":\"backend.serviceman.edit\",\"destroy\":\"backend.serviceman.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(83,'coupons','{\"index\":\"backend.coupon.index\",\"create\":\"backend.coupon.create\",\"edit\":\"backend.coupon.edit\",\"destroy\":\"backend.coupon.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(84,'backups','{\"index\":\"backend.backup.index\",\"create\":\"backend.backup.create\",\"edit\":\"backend.backup.edit\",\"trash\":\"backend.backup.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(85,'system_tools','{\"index\":\"backend.system_tool.index\",\"create\":\"backend.system_tool.create\",\"edit\":\"backend.system_tool.edit\",\"trash\":\"backend.system_tool.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(86,'wallets','{\"index\":\"backend.wallet.index\",\"credit\":\"backend.wallet.credit\",\"debit\":\"backend.wallet.debit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(87,'sliders','{\"index\":\"backend.slider.index\",\"create\":\"backend.slider.create\",\"edit\":\"backend.slider.edit\",\"destroy\":\"backend.slider.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(88,'reviews','{\"index\":\"backend.review.index\",\"create\":\"backend.review.create\",\"edit\":\"backend.review.edit\",\"destroy\":\"backend.review.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(89,'earnings','{\"index\":\"backend.earning.index\",\"create\":\"backend.earning.create\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(90,'taxes','{\"index\":\"backend.tax.index\",\"create\":\"backend.tax.create\",\"edit\":\"backend.tax.edit\",\"destroy\":\"backend.tax.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(91,'users','{\"index\":\"backend.user.index\",\"create\":\"backend.user.create\",\"edit\":\"backend.user.edit\",\"destroy\":\"backend.user.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(92,'zone_managers','{\"index\":\"backend.zone_manager.index\",\"create\":\"backend.zone_manager.create\",\"edit\":\"backend.zone_manager.edit\",\"destroy\":\"backend.zone_manager.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(93,'customers','{\"index\":\"backend.customer.index\",\"create\":\"backend.customer.create\",\"edit\":\"backend.customer.edit\",\"destroy\":\"backend.customer.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(94,'payment_transactions','{\"index\":\"backend.payment_transaction.index\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(95,'documents','{\"index\":\"backend.document.index\",\"create\":\"backend.document.create\",\"edit\":\"backend.document.edit\",\"destroy\":\"backend.document.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(96,'currencies','{\"index\":\"backend.currency.index\",\"create\":\"backend.currency.create\",\"edit\":\"backend.currency.edit\",\"destroy\":\"backend.currency.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(97,'tags','{\"index\":\"backend.tag.index\",\"create\":\"backend.tag.create\",\"edit\":\"backend.tag.edit\",\"destroy\":\"backend.tag.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(98,'blogs','{\"index\":\"backend.blog.index\",\"create\":\"backend.blog.create\",\"edit\":\"backend.blog.edit\",\"destroy\":\"backend.blog.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(99,'pages','{\"index\":\"backend.page.index\",\"create\":\"backend.page.create\",\"edit\":\"backend.page.edit\",\"destroy\":\"backend.page.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(100,'provider_time_slots','{\"index\":\"backend.provider_time_slot.index\",\"create\":\"backend.provider_time_slot.create\",\"edit\":\"backend.provider_time_slot.edit\",\"destroy\":\"backend.provider_time_slot.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(101,'provider_documents','{\"index\":\"backend.provider_document.index\",\"create\":\"backend.provider_document.create\",\"edit\":\"backend.provider_document.edit\",\"destroy\":\"backend.provider_document.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(102,'serviceman_documents','{\"index\":\"backend.serviceman_document.index\",\"create\":\"backend.serviceman_document.create\",\"edit\":\"backend.serviceman_document.edit\",\"destroy\":\"backend.serviceman_document.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(103,'banners','{\"index\":\"backend.banner.index\",\"create\":\"backend.banner.create\",\"edit\":\"backend.banner.edit\",\"destroy\":\"backend.banner.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(104,'advertisements','{\"index\":\"backend.advertisement.index\",\"create\":\"backend.advertisement.create\",\"edit\":\"backend.advertisement.edit\",\"destroy\":\"backend.advertisement.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(105,'settings','{\"index\":\"backend.setting.index\",\"create\":\"backend.setting.create\",\"edit\":\"backend.setting.edit\",\"destroy\":\"backend.setting.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(106,'payment_methods','{\"index\":\"backend.payment_method.index\",\"create\":\"backend.payment_method.create\",\"edit\":\"backend.payment_method.edit\",\"destroy\":\"backend.payment_method.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(107,'sms_gateways','{\"index\":\"backend.sms_gateway.index\",\"edit\":\"backend.sms_gateway.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(108,'languages','{\"index\":\"backend.language.index\",\"create\":\"backend.language.create\",\"edit\":\"backend.language.edit\",\"destroy\":\"backend.language.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(109,'push_notifications','{\"index\":\"backend.push_notification.index\",\"create\":\"backend.push_notification.create\",\"edit\":\"backend.push_notification.edit\",\"destroy\":\"backend.push_notification.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(110,'bids','{\"index\":\"backend.bid.index\",\"create\":\"backend.bid.create\",\"edit\":\"backend.bid.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(111,'zones','{\"index\":\"backend.zone.index\",\"create\":\"backend.zone.create\",\"edit\":\"backend.zone.edit\",\"destroy\":\"backend.zone.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(112,'home_pages','{\"index\":\"backend.home_page.index\",\"edit\":\"backend.home_page.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(113,'customizations','{\"index\":\"backend.customization.index\",\"edit\":\"backend.customization.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(114,'testimonials','{\"index\":\"backend.testimonial.index\",\"create\":\"backend.testimonial.create\",\"edit\":\"backend.testimonial.edit\",\"destroy\":\"backend.testimonial.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(115,'theme_options','{\"index\":\"backend.theme_option.index\",\"edit\":\"backend.theme_option.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(116,'news_letters','{\"index\":\"backend.news_letter.index\",\"create\":\"backend.news_letter.create\",\"edit\":\"backend.news_letter.edit\",\"destroy\":\"backend.news_letter.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(117,'sms_templates','{\"index\":\"backend.sms_template.index\",\"edit\":\"backend.sms_template.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(118,'email_templates','{\"index\":\"backend.email_template.index\",\"edit\":\"backend.email_template.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(119,'push_notification_templates','{\"index\":\"backend.push_notification_template.index\",\"edit\":\"backend.push_notification_template.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(120,'service_request','{\"index\":\"backend.service_request.index\",\"create\":\"backend.service_request.create\",\"edit\":\"backend.service_request.edit\",\"destroy\":\"backend.service_request.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(121,'custom_sms_gateways','{\"index\":\"backend.custom_sms_gateway.index\",\"edit\":\"backend.custom_sms_gateway.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(122,'provider_dashboard','{\"index\":\"backend.provider_dashboard.index\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(123,'consumer_dashboard','{\"index\":\"backend.consumer_dashboard.index\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(124,'servicemen_dashboard','{\"index\":\"backend.servicemen_dashboard.index\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(125,'unverified_user','{\"index\":\"backend.unverified_user.index\",\"edit\":\"backend.unverified_user.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(126,'serviceman_locations','{\"index\":\"backend.serviceman_location.index\",\"create\":\"backend.serviceman_location.create\",\"edit\":\"backend.serviceman_location.edit\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(127,'reports','{\"index\":\"backend.report.index\",\"create\":\"backend.report.create\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(128,'referrals','{\"index\":\"backend.referral.index\",\"create\":\"backend.referral.create\",\"edit\":\"backend.referral.edit\",\"destroy\":\"backend.referral.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(129,'chats','{\"index\":\"backend.chat.index\",\"send\":\"backend.chat.send\",\"reply\":\"backend.chat.replay\",\"destroy\":\"backend.chat.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(130,'wallet_bonuses','{\"index\":\"backend.wallet_bonus.index\",\"send\":\"backend.wallet_bonus.send\",\"reply\":\"backend.wallet_bonus.replay\",\"destroy\":\"backend.wallet_bonus.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(131,'seo_settings','{\"index\":\"backend.seo_setting.index\",\"create\":\"backend.seo_setting.create\",\"edit\":\"backend.seo_setting.edit\",\"destroy\":\"backend.seo_setting.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52'),(132,'custom_ai_model','{\"index\":\"backend.custom_ai_model.index\",\"create\":\"backend.custom_ai_model.create\",\"edit\":\"backend.custom_ai_model.edit\",\"destroy\":\"backend.custom_ai_model.destroy\"}','2026-05-27 14:39:52','2026-05-27 14:39:52');
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `onboarding_logs`
--

DROP TABLE IF EXISTS `onboarding_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `onboarding_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `step` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `onboarding_logs_user_id_step_index` (`user_id`,`step`),
  CONSTRAINT `onboarding_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `onboarding_logs`
--

LOCK TABLES `onboarding_logs` WRITE;
/*!40000 ALTER TABLE `onboarding_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `onboarding_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` longtext COLLATE utf8mb4_unicode_ci,
  `status` int NOT NULL DEFAULT '1',
  `app_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pages_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `pages_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateways`
--

DROP TABLE IF EXISTS `payment_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_gateways` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serial` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `mode` enum('live','sandbox') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sandbox',
  `configs` json DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateways`
--

LOCK TABLES `payment_gateways` WRITE;
/*!40000 ALTER TABLE `payment_gateways` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_gateways` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateways_transactions`
--

DROP TABLE IF EXISTS `payment_gateways_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_gateways_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `item_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `transaction_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_type` enum('web','api') COLLATE utf8mb4_unicode_ci DEFAULT 'api',
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payment_gateways_transactions_transaction_id_unique` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateways_transactions`
--

LOCK TABLES `payment_gateways_transactions` WRITE;
/*!40000 ALTER TABLE `payment_gateways_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_gateways_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=220 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'backend.role.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(2,'backend.role.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(3,'backend.role.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(4,'backend.role.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(5,'backend.bank_detail.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(6,'backend.bank_detail.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(7,'backend.bank_detail.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(8,'backend.bank_detail.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(9,'backend.service_category.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(10,'backend.service_category.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(11,'backend.service_category.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(12,'backend.service_category.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(13,'backend.blog_category.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(14,'backend.blog_category.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(15,'backend.blog_category.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(16,'backend.blog_category.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(17,'backend.service.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(18,'backend.service.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(19,'backend.service.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(20,'backend.service.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(21,'backend.plan.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(22,'backend.plan.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(23,'backend.plan.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(24,'backend.plan.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(25,'backend.service-package.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(26,'backend.service-package.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(27,'backend.service-package.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(28,'backend.service-package.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(29,'backend.booking.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(30,'backend.booking.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(31,'backend.booking.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(32,'backend.custom_offer.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(33,'backend.custom_offer.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(34,'backend.custom_offer.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(35,'backend.custom_offer.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(36,'backend.provider.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(37,'backend.provider.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(38,'backend.provider.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(39,'backend.provider.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(40,'backend.provider_wallet.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(41,'backend.provider_wallet.credit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(42,'backend.provider_wallet.debit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(43,'backend.serviceman_wallet.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(44,'backend.serviceman_wallet.credit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(45,'backend.serviceman_wallet.debit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(46,'backend.commission_history.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(47,'backend.withdraw_request.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(48,'backend.withdraw_request.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(49,'backend.withdraw_request.action','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(50,'backend.serviceman_withdraw_request.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(51,'backend.serviceman_withdraw_request.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(52,'backend.serviceman_withdraw_request.action','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(53,'backend.serviceman.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(54,'backend.serviceman.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(55,'backend.serviceman.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(56,'backend.serviceman.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(57,'backend.coupon.index','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(58,'backend.coupon.create','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(59,'backend.coupon.edit','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(60,'backend.coupon.destroy','web','2026-05-27 14:39:42','2026-05-27 14:39:42'),(61,'backend.backup.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(62,'backend.backup.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(63,'backend.backup.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(64,'backend.backup.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(65,'backend.system_tool.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(66,'backend.system_tool.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(67,'backend.system_tool.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(68,'backend.system_tool.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(69,'backend.wallet.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(70,'backend.wallet.credit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(71,'backend.wallet.debit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(72,'backend.slider.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(73,'backend.slider.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(74,'backend.slider.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(75,'backend.slider.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(76,'backend.review.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(77,'backend.review.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(78,'backend.review.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(79,'backend.review.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(80,'backend.earning.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(81,'backend.earning.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(82,'backend.tax.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(83,'backend.tax.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(84,'backend.tax.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(85,'backend.tax.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(86,'backend.user.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(87,'backend.user.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(88,'backend.user.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(89,'backend.user.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(90,'backend.zone_manager.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(91,'backend.zone_manager.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(92,'backend.zone_manager.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(93,'backend.zone_manager.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(94,'backend.customer.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(95,'backend.customer.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(96,'backend.customer.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(97,'backend.customer.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(98,'backend.payment_transaction.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(99,'backend.document.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(100,'backend.document.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(101,'backend.document.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(102,'backend.document.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(103,'backend.currency.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(104,'backend.currency.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(105,'backend.currency.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(106,'backend.currency.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(107,'backend.tag.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(108,'backend.tag.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(109,'backend.tag.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(110,'backend.tag.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(111,'backend.blog.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(112,'backend.blog.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(113,'backend.blog.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(114,'backend.blog.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(115,'backend.page.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(116,'backend.page.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(117,'backend.page.edit','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(118,'backend.page.destroy','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(119,'backend.provider_time_slot.index','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(120,'backend.provider_time_slot.create','web','2026-05-27 14:39:43','2026-05-27 14:39:43'),(121,'backend.provider_time_slot.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(122,'backend.provider_time_slot.destroy','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(123,'backend.provider_document.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(124,'backend.provider_document.create','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(125,'backend.provider_document.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(126,'backend.provider_document.destroy','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(127,'backend.serviceman_document.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(128,'backend.serviceman_document.create','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(129,'backend.serviceman_document.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(130,'backend.serviceman_document.destroy','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(131,'backend.banner.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(132,'backend.banner.create','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(133,'backend.banner.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(134,'backend.banner.destroy','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(135,'backend.advertisement.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(136,'backend.advertisement.create','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(137,'backend.advertisement.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(138,'backend.advertisement.destroy','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(139,'backend.setting.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(140,'backend.setting.create','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(141,'backend.setting.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(142,'backend.setting.destroy','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(143,'backend.payment_method.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(144,'backend.payment_method.create','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(145,'backend.payment_method.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(146,'backend.payment_method.destroy','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(147,'backend.sms_gateway.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(148,'backend.sms_gateway.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(149,'backend.language.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(150,'backend.language.create','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(151,'backend.language.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(152,'backend.language.destroy','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(153,'backend.push_notification.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(154,'backend.push_notification.create','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(155,'backend.push_notification.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(156,'backend.push_notification.destroy','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(157,'backend.bid.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(158,'backend.bid.create','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(159,'backend.bid.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(160,'backend.zone.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(161,'backend.zone.create','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(162,'backend.zone.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(163,'backend.zone.destroy','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(164,'backend.home_page.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(165,'backend.home_page.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(166,'backend.customization.index','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(167,'backend.customization.edit','web','2026-05-27 14:39:44','2026-05-27 14:39:44'),(168,'backend.testimonial.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(169,'backend.testimonial.create','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(170,'backend.testimonial.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(171,'backend.testimonial.destroy','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(172,'backend.theme_option.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(173,'backend.theme_option.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(174,'backend.news_letter.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(175,'backend.news_letter.create','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(176,'backend.news_letter.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(177,'backend.news_letter.destroy','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(178,'backend.sms_template.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(179,'backend.sms_template.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(180,'backend.email_template.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(181,'backend.email_template.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(182,'backend.push_notification_template.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(183,'backend.push_notification_template.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(184,'backend.service_request.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(185,'backend.service_request.create','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(186,'backend.service_request.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(187,'backend.service_request.destroy','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(188,'backend.custom_sms_gateway.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(189,'backend.custom_sms_gateway.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(190,'backend.provider_dashboard.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(191,'backend.consumer_dashboard.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(192,'backend.servicemen_dashboard.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(193,'backend.unverified_user.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(194,'backend.unverified_user.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(195,'backend.serviceman_location.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(196,'backend.serviceman_location.create','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(197,'backend.serviceman_location.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(198,'backend.report.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(199,'backend.report.create','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(200,'backend.referral.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(201,'backend.referral.create','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(202,'backend.referral.edit','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(203,'backend.referral.destroy','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(204,'backend.chat.index','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(205,'backend.chat.send','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(206,'backend.chat.replay','web','2026-05-27 14:39:45','2026-05-27 14:39:45'),(207,'backend.chat.destroy','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(208,'backend.wallet_bonus.index','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(209,'backend.wallet_bonus.send','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(210,'backend.wallet_bonus.replay','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(211,'backend.wallet_bonus.destroy','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(212,'backend.seo_setting.index','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(213,'backend.seo_setting.create','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(214,'backend.seo_setting.edit','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(215,'backend.seo_setting.destroy','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(216,'backend.custom_ai_model.index','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(217,'backend.custom_ai_model.create','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(218,'backend.custom_ai_model.edit','web','2026-05-27 14:39:46','2026-05-27 14:39:46'),(219,'backend.custom_ai_model.destroy','web','2026-05-27 14:39:46','2026-05-27 14:39:46');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',19,'auth_token','5cf0e699e29f21f6d88c0949ae2382954980984c6baaac3a13c69a234a3abd67','[\"*\"]','2026-05-28 10:13:38',NULL,'2026-05-28 08:37:49','2026-05-28 10:13:38'),(2,'App\\Models\\User',19,'auth_token','4d8ae01f21b511a392a37db4a011af90a6aaec716342742084f7e51ea284ab6b','[\"*\"]','2026-05-28 08:43:24',NULL,'2026-05-28 08:40:39','2026-05-28 08:43:24');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_services` int NOT NULL,
  `max_addresses` int NOT NULL,
  `max_servicemen` int NOT NULL,
  `max_service_packages` int NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `duration` enum('monthly','yearly') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` bigint unsigned DEFAULT NULL,
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plans_product_id_unique` (`product_id`),
  KEY `plans_created_by_foreign` (`created_by`),
  CONSTRAINT `plans_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_transactions`
--

DROP TABLE IF EXISTS `provider_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `provider_wallet_id` bigint unsigned DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `type` enum('credit','debit') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `provider_transactions_provider_wallet_id_foreign` (`provider_wallet_id`),
  KEY `provider_transactions_provider_id_foreign` (`provider_id`),
  KEY `provider_transactions_from_foreign` (`from`),
  CONSTRAINT `provider_transactions_from_foreign` FOREIGN KEY (`from`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `provider_transactions_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `provider_transactions_provider_wallet_id_foreign` FOREIGN KEY (`provider_wallet_id`) REFERENCES `provider_wallets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_transactions`
--

LOCK TABLES `provider_transactions` WRITE;
/*!40000 ALTER TABLE `provider_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_verifications`
--

DROP TABLE IF EXISTS `provider_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_verifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `inn` varchar(12) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxpayer_type` enum('self_employed','individual_entrepreneur','legal_entity','ip_on_npd') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `legal_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `director_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ogrn` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registration_date` date DEFAULT NULL,
  `inn_status` enum('active','liquidated','suspended','not_found') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inn_verified_at` timestamp NULL DEFAULT NULL,
  `inn_raw_response` json DEFAULT NULL,
  `npd_status` enum('active','inactive','not_applicable','pending') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `npd_verified_at` timestamp NULL DEFAULT NULL,
  `npd_raw_response` json DEFAULT NULL,
  `okveds` json DEFAULT NULL,
  `okved_warning` tinyint(1) NOT NULL DEFAULT '0',
  `passport_series` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_number` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_issued_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_issued_date` date DEFAULT NULL,
  `passport_dept_code` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_photo_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_selfie_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_status` enum('pending','verified','rejected','manual_review') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_verified_at` timestamp NULL DEFAULT NULL,
  `passport_raw_response` json DEFAULT NULL,
  `fssp_status` enum('clean','has_debts','manual_review') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fssp_debt_amount` decimal(12,2) DEFAULT NULL,
  `fssp_checked_at` timestamp NULL DEFAULT NULL,
  `fssp_raw_response` json DEFAULT NULL,
  `contract_type` enum('self_employed','ip','ooo','gph') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contract_version` smallint unsigned DEFAULT NULL,
  `payments_frozen` tinyint(1) NOT NULL DEFAULT '0',
  `payments_frozen_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payments_frozen_at` timestamp NULL DEFAULT NULL,
  `contract_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contract_signed_at` timestamp NULL DEFAULT NULL,
  `contract_sign_method` enum('sms_otp','ukep') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sms_otp',
  `contract_sms_code` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contract_sms_sent_at` timestamp NULL DEFAULT NULL,
  `contract_ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `power_of_attorney_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signatory_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `onboarding_status` enum('in_progress','pending_manual','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'in_progress',
  `manual_review_reason` text COLLATE utf8mb4_unicode_ci,
  `reviewed_by` bigint unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `provider_verifications_user_id_foreign` (`user_id`),
  KEY `provider_verifications_reviewed_by_foreign` (`reviewed_by`),
  KEY `provider_verifications_onboarding_status_index` (`onboarding_status`),
  KEY `provider_verifications_inn_index` (`inn`),
  KEY `provider_verifications_payments_frozen_index` (`payments_frozen`),
  CONSTRAINT `provider_verifications_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `provider_verifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_verifications`
--

LOCK TABLES `provider_verifications` WRITE;
/*!40000 ALTER TABLE `provider_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider_verifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_wallets`
--

DROP TABLE IF EXISTS `provider_wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `provider_id` bigint unsigned DEFAULT NULL,
  `balance` decimal(8,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `provider_wallets_provider_id_foreign` (`provider_id`),
  CONSTRAINT `provider_wallets_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_wallets`
--

LOCK TABLES `provider_wallets` WRITE;
/*!40000 ALTER TABLE `provider_wallets` DISABLE KEYS */;
INSERT INTO `provider_wallets` VALUES (1,19,0.00,'2026-05-28 08:37:51','2026-05-28 08:37:51',NULL);
/*!40000 ALTER TABLE `provider_wallets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provider_zones`
--

DROP TABLE IF EXISTS `provider_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `provider_zones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `provider_id` bigint unsigned NOT NULL,
  `zone_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `provider_zones_provider_id_foreign` (`provider_id`),
  KEY `provider_zones_zone_id_foreign` (`zone_id`),
  CONSTRAINT `provider_zones_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `provider_zones_zone_id_foreign` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provider_zones`
--

LOCK TABLES `provider_zones` WRITE;
/*!40000 ALTER TABLE `provider_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `provider_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_notification_templates`
--

DROP TABLE IF EXISTS `push_notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_notification_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `url` longtext COLLATE utf8mb4_unicode_ci,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_notification_templates`
--

LOCK TABLES `push_notification_templates` WRITE;
/*!40000 ALTER TABLE `push_notification_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_notification_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_notifications`
--

DROP TABLE IF EXISTS `push_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `push_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `send_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `image_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notification_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `push_notifications_user_id_foreign` (`user_id`),
  KEY `push_notifications_created_by_foreign` (`created_by`),
  KEY `push_notifications_service_id_foreign` (`service_id`),
  CONSTRAINT `push_notifications_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `push_notifications_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `push_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_notifications`
--

LOCK TABLES `push_notifications` WRITE;
/*!40000 ALTER TABLE `push_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating`
--

DROP TABLE IF EXISTS `rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rating` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `rating` int DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consumer_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rating_consumer_id_foreign` (`consumer_id`),
  CONSTRAINT `rating_consumer_id_foreign` FOREIGN KEY (`consumer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating`
--

LOCK TABLES `rating` WRITE;
/*!40000 ALTER TABLE `rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recurring_bookings`
--

DROP TABLE IF EXISTS `recurring_bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recurring_bookings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint unsigned DEFAULT NULL,
  `consumer_id` bigint unsigned NOT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  `address_id` bigint unsigned DEFAULT NULL,
  `frequency` enum('weekly','monthly','yearly') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `total_occurrences` int DEFAULT NULL,
  `occurrences_completed` int NOT NULL DEFAULT '0',
  `next_booking_date` date DEFAULT NULL,
  `subscription_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `status` enum('active','paused','cancelled','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `booking_data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recurring_bookings_booking_id_foreign` (`booking_id`),
  KEY `recurring_bookings_provider_id_foreign` (`provider_id`),
  KEY `recurring_bookings_service_id_foreign` (`service_id`),
  KEY `recurring_bookings_address_id_foreign` (`address_id`),
  KEY `recurring_bookings_consumer_id_is_active_index` (`consumer_id`,`is_active`),
  KEY `recurring_bookings_subscription_id_index` (`subscription_id`),
  KEY `recurring_bookings_next_booking_date_index` (`next_booking_date`),
  CONSTRAINT `recurring_bookings_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recurring_bookings_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recurring_bookings_consumer_id_foreign` FOREIGN KEY (`consumer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recurring_bookings_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `recurring_bookings_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recurring_bookings`
--

LOCK TABLES `recurring_bookings` WRITE;
/*!40000 ALTER TABLE `recurring_bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `recurring_bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `referral_bonuses`
--

DROP TABLE IF EXISTS `referral_bonuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `referral_bonuses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `referrer_id` bigint unsigned NOT NULL,
  `referred_id` bigint unsigned NOT NULL,
  `bonus_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `referrer_type` enum('user','provider') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `referred_type` enum('user','provider') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `booking_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `referrer_percentage` decimal(5,2) NOT NULL DEFAULT '0.00',
  `referred_percentage` decimal(5,2) NOT NULL DEFAULT '0.00',
  `referred_bonus_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `referrer_bonus_amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `currency_symbol` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credited_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `referral_bonuses_referrer_id_index` (`referrer_id`),
  KEY `referral_bonuses_referred_id_index` (`referred_id`),
  CONSTRAINT `referral_bonuses_referred_id_foreign` FOREIGN KEY (`referred_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `referral_bonuses_referrer_id_foreign` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `referral_bonuses`
--

LOCK TABLES `referral_bonuses` WRITE;
/*!40000 ALTER TABLE `referral_bonuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `referral_bonuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `related_services`
--

DROP TABLE IF EXISTS `related_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `related_services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `service_id` bigint unsigned DEFAULT NULL,
  `related_service_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `related_services_service_id_foreign` (`service_id`),
  KEY `related_services_related_service_id_foreign` (`related_service_id`),
  CONSTRAINT `related_services_related_service_id_foreign` FOREIGN KEY (`related_service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `related_services_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `related_services`
--

LOCK TABLES `related_services` WRITE;
/*!40000 ALTER TABLE `related_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `related_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `service_id` bigint unsigned DEFAULT NULL,
  `serviceman_id` bigint unsigned DEFAULT NULL,
  `consumer_id` bigint unsigned DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `rating` decimal(8,2) DEFAULT '0.00',
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_service_id_foreign` (`service_id`),
  KEY `reviews_serviceman_id_foreign` (`serviceman_id`),
  KEY `reviews_consumer_id_foreign` (`consumer_id`),
  KEY `reviews_provider_id_foreign` (`provider_id`),
  CONSTRAINT `reviews_consumer_id_foreign` FOREIGN KEY (`consumer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_serviceman_id_foreign` FOREIGN KEY (`serviceman_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,1),(43,1),(44,1),(45,1),(46,1),(47,1),(48,1),(49,1),(50,1),(51,1),(52,1),(53,1),(54,1),(55,1),(56,1),(57,1),(58,1),(59,1),(60,1),(61,1),(62,1),(63,1),(64,1),(65,1),(66,1),(67,1),(68,1),(69,1),(70,1),(71,1),(72,1),(73,1),(74,1),(75,1),(76,1),(77,1),(78,1),(79,1),(80,1),(81,1),(82,1),(83,1),(84,1),(85,1),(86,1),(87,1),(88,1),(89,1),(90,1),(91,1),(92,1),(93,1),(94,1),(95,1),(96,1),(97,1),(98,1),(99,1),(100,1),(101,1),(102,1),(103,1),(104,1),(105,1),(106,1),(107,1),(108,1),(109,1),(110,1),(111,1),(112,1),(113,1),(114,1),(115,1),(116,1),(117,1),(118,1),(119,1),(120,1),(121,1),(122,1),(123,1),(124,1),(125,1),(126,1),(127,1),(128,1),(129,1),(130,1),(131,1),(132,1),(133,1),(134,1),(135,1),(136,1),(137,1),(138,1),(139,1),(140,1),(141,1),(142,1),(143,1),(144,1),(145,1),(146,1),(147,1),(148,1),(149,1),(150,1),(151,1),(152,1),(153,1),(154,1),(155,1),(156,1),(157,1),(158,1),(159,1),(160,1),(161,1),(162,1),(163,1),(164,1),(165,1),(166,1),(167,1),(168,1),(169,1),(170,1),(171,1),(172,1),(173,1),(174,1),(175,1),(176,1),(177,1),(178,1),(179,1),(180,1),(181,1),(182,1),(183,1),(184,1),(185,1),(186,1),(187,1),(188,1),(189,1),(190,1),(191,1),(192,1),(193,1),(194,1),(195,1),(196,1),(197,1),(198,1),(199,1),(200,1),(201,1),(202,1),(203,1),(204,1),(205,1),(206,1),(207,1),(208,1),(209,1),(210,1),(211,1),(212,1),(213,1),(214,1),(215,1),(216,1),(217,1),(218,1),(219,1),(5,2),(6,2),(7,2),(29,2),(30,2),(31,2),(32,2),(33,2),(34,2),(36,2),(76,2),(77,2),(78,2),(79,2),(111,2),(115,2),(131,2),(135,2),(153,2),(154,2),(157,2),(159,2),(184,2),(185,2),(187,2),(188,2),(200,2),(204,2),(207,2),(208,2),(5,3),(6,3),(7,3),(17,3),(18,3),(19,3),(20,3),(21,3),(25,3),(26,3),(27,3),(28,3),(29,3),(31,3),(32,3),(33,3),(34,3),(40,3),(46,3),(47,3),(48,3),(50,3),(52,3),(53,3),(54,3),(55,3),(56,3),(76,3),(98,3),(119,3),(120,3),(121,3),(122,3),(123,3),(124,3),(125,3),(131,3),(135,3),(136,3),(137,3),(138,3),(153,3),(155,3),(157,3),(158,3),(184,3),(186,3),(195,3),(196,3),(197,3),(200,3),(204,3),(207,3),(5,4),(6,4),(7,4),(29,4),(31,4),(43,4),(50,4),(51,4),(127,4),(128,4),(129,4),(192,4),(204,4),(207,4);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `system_reserve` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','web',1,'2026-05-27 14:39:46','2026-05-27 14:39:46'),(2,'user','web',1,'2026-05-27 14:39:46','2026-05-27 14:39:46'),(3,'provider','web',1,'2026-05-27 14:39:46','2026-05-27 14:39:46'),(4,'serviceman','web',0,'2026-05-27 14:40:52','2026-05-27 14:40:52');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seeders`
--

DROP TABLE IF EXISTS `seeders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seeders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_completed` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seeders`
--

LOCK TABLES `seeders` WRITE;
/*!40000 ALTER TABLE `seeders` DISABLE KEYS */;
/*!40000 ALTER TABLE `seeders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo`
--

DROP TABLE IF EXISTS `seo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `robots` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `canonical_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seo_model_type_model_id_index` (`model_type`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo`
--

LOCK TABLES `seo` WRITE;
/*!40000 ALTER TABLE `seo` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seo_settings`
--

DROP TABLE IF EXISTS `seo_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `page_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci,
  `og_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `og_description` text COLLATE utf8mb4_unicode_ci,
  `twitter_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_description` text COLLATE utf8mb4_unicode_ci,
  `canonical_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `robots` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'index,follow',
  `schema_markup` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `seo_settings_page_slug_unique` (`page_slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seo_settings`
--

LOCK TABLES `seo_settings` WRITE;
/*!40000 ALTER TABLE `seo_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `seo_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_address`
--

DROP TABLE IF EXISTS `service_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_address` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `service_id` bigint unsigned NOT NULL,
  `address_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_address_service_id_foreign` (`service_id`),
  KEY `service_address_address_id_foreign` (`address_id`),
  CONSTRAINT `service_address_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_address_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_address`
--

LOCK TABLES `service_address` WRITE;
/*!40000 ALTER TABLE `service_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_availabilities`
--

DROP TABLE IF EXISTS `service_availabilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_availabilities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `company_id` bigint unsigned DEFAULT NULL,
  `address_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_availabilities_company_id_foreign` (`company_id`),
  KEY `service_availabilities_address_id_foreign` (`address_id`),
  KEY `service_availabilities_user_id_foreign` (`user_id`),
  KEY `service_availabilities_service_id_foreign` (`service_id`),
  CONSTRAINT `service_availabilities_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_availabilities_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_availabilities_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_availabilities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_availabilities`
--

LOCK TABLES `service_availabilities` WRITE;
/*!40000 ALTER TABLE `service_availabilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_availabilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_categories`
--

DROP TABLE IF EXISTS `service_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `service_id` bigint unsigned NOT NULL,
  `category_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_categories_service_id_foreign` (`service_id`),
  KEY `service_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `service_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_categories_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_categories`
--

LOCK TABLES `service_categories` WRITE;
/*!40000 ALTER TABLE `service_categories` DISABLE KEYS */;
INSERT INTO `service_categories` VALUES (1,1,5),(2,2,5);
/*!40000 ALTER TABLE `service_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_faqs`
--

DROP TABLE IF EXISTS `service_faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_faqs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `service_id` bigint unsigned NOT NULL,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_faqs_service_id_foreign` (`service_id`),
  CONSTRAINT `service_faqs_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_faqs`
--

LOCK TABLES `service_faqs` WRITE;
/*!40000 ALTER TABLE `service_faqs` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_package_services`
--

DROP TABLE IF EXISTS `service_package_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_package_services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `service_package_id` bigint unsigned NOT NULL,
  `service_id` bigint unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_package_services_service_package_id_foreign` (`service_package_id`),
  KEY `service_package_services_service_id_foreign` (`service_id`),
  CONSTRAINT `service_package_services_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_package_services_service_package_id_foreign` FOREIGN KEY (`service_package_id`) REFERENCES `service_packages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_package_services`
--

LOCK TABLES `service_package_services` WRITE;
/*!40000 ALTER TABLE `service_package_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_package_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_packages`
--

DROP TABLE IF EXISTS `service_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_packages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `disclaimer` longtext COLLATE utf8mb4_unicode_ci,
  `discount` decimal(8,2) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) DEFAULT '0',
  `hexa_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bg_color` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'primary',
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `created_by_id` bigint unsigned DEFAULT NULL,
  `started_at` date DEFAULT NULL,
  `ended_at` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_packages_provider_id_foreign` (`provider_id`),
  CONSTRAINT `service_packages_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_packages`
--

LOCK TABLES `service_packages` WRITE;
/*!40000 ALTER TABLE `service_packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_proofs`
--

DROP TABLE IF EXISTS `service_proofs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_proofs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint unsigned DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_proofs_booking_id_foreign` (`booking_id`),
  CONSTRAINT `service_proofs_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_proofs`
--

LOCK TABLES `service_proofs` WRITE;
/*!40000 ALTER TABLE `service_proofs` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_proofs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_requests`
--

DROP TABLE IF EXISTS `service_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `required_servicemen` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `initial_price` decimal(10,2) DEFAULT NULL,
  `final_price` decimal(10,2) DEFAULT NULL,
  `status` enum('open','pending','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `service_id` bigint unsigned DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `created_by_id` bigint unsigned DEFAULT NULL,
  `booking_date` datetime DEFAULT NULL,
  `category_ids` json DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `service_requests_service_id_foreign` (`service_id`),
  KEY `service_requests_user_id_foreign` (`user_id`),
  KEY `service_requests_provider_id_foreign` (`provider_id`),
  KEY `service_requests_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `service_requests_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_requests_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_requests_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_requests`
--

LOCK TABLES `service_requests` WRITE;
/*!40000 ALTER TABLE `service_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_taxes`
--

DROP TABLE IF EXISTS `service_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_taxes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `service_id` bigint unsigned NOT NULL,
  `tax_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `service_taxes_service_id_foreign` (`service_id`),
  KEY `service_taxes_tax_id_foreign` (`tax_id`),
  CONSTRAINT `service_taxes_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `service_taxes_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_taxes`
--

LOCK TABLES `service_taxes` WRITE;
/*!40000 ALTER TABLE `service_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serviceman_commissions`
--

DROP TABLE IF EXISTS `serviceman_commissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `serviceman_commissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `commission_history_id` bigint unsigned NOT NULL,
  `serviceman_id` bigint unsigned NOT NULL,
  `commission` decimal(8,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceman_commissions_commission_history_id_foreign` (`commission_history_id`),
  KEY `serviceman_commissions_serviceman_id_foreign` (`serviceman_id`),
  CONSTRAINT `serviceman_commissions_commission_history_id_foreign` FOREIGN KEY (`commission_history_id`) REFERENCES `commission_histories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `serviceman_commissions_serviceman_id_foreign` FOREIGN KEY (`serviceman_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serviceman_commissions`
--

LOCK TABLES `serviceman_commissions` WRITE;
/*!40000 ALTER TABLE `serviceman_commissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `serviceman_commissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serviceman_transactions`
--

DROP TABLE IF EXISTS `serviceman_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `serviceman_transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `serviceman_wallet_id` bigint unsigned DEFAULT NULL,
  `serviceman_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `type` enum('credit','debit') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceman_transactions_serviceman_wallet_id_foreign` (`serviceman_wallet_id`),
  KEY `serviceman_transactions_serviceman_id_foreign` (`serviceman_id`),
  KEY `serviceman_transactions_from_foreign` (`from`),
  CONSTRAINT `serviceman_transactions_from_foreign` FOREIGN KEY (`from`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `serviceman_transactions_serviceman_id_foreign` FOREIGN KEY (`serviceman_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `serviceman_transactions_serviceman_wallet_id_foreign` FOREIGN KEY (`serviceman_wallet_id`) REFERENCES `serviceman_wallets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serviceman_transactions`
--

LOCK TABLES `serviceman_transactions` WRITE;
/*!40000 ALTER TABLE `serviceman_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `serviceman_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serviceman_wallets`
--

DROP TABLE IF EXISTS `serviceman_wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `serviceman_wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `serviceman_id` bigint unsigned DEFAULT NULL,
  `balance` decimal(8,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceman_wallets_serviceman_id_foreign` (`serviceman_id`),
  CONSTRAINT `serviceman_wallets_serviceman_id_foreign` FOREIGN KEY (`serviceman_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serviceman_wallets`
--

LOCK TABLES `serviceman_wallets` WRITE;
/*!40000 ALTER TABLE `serviceman_wallets` DISABLE KEYS */;
/*!40000 ALTER TABLE `serviceman_wallets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serviceman_withdraw_requests`
--

DROP TABLE IF EXISTS `serviceman_withdraw_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `serviceman_withdraw_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `amount` decimal(8,2) DEFAULT '0.00',
  `message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `serviceman_wallet_id` bigint unsigned DEFAULT NULL,
  `serviceman_id` bigint unsigned DEFAULT NULL,
  `payment_type` enum('paypal','bank') COLLATE utf8mb4_unicode_ci DEFAULT 'bank',
  `is_used_by_admin` int NOT NULL DEFAULT '0',
  `is_used` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `serviceman_withdraw_requests_serviceman_wallet_id_foreign` (`serviceman_wallet_id`),
  KEY `serviceman_withdraw_requests_serviceman_id_foreign` (`serviceman_id`),
  CONSTRAINT `serviceman_withdraw_requests_serviceman_id_foreign` FOREIGN KEY (`serviceman_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `serviceman_withdraw_requests_serviceman_wallet_id_foreign` FOREIGN KEY (`serviceman_wallet_id`) REFERENCES `serviceman_wallets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serviceman_withdraw_requests`
--

LOCK TABLES `serviceman_withdraw_requests` WRITE;
/*!40000 ALTER TABLE `serviceman_withdraw_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `serviceman_withdraw_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration_unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_rate` decimal(8,2) DEFAULT NULL,
  `discount` decimal(8,2) DEFAULT NULL,
  `per_serviceman_commission` decimal(4,2) DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `video` json DEFAULT NULL,
  `speciality_description` longtext COLLATE utf8mb4_unicode_ci,
  `user_id` bigint unsigned DEFAULT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `type` enum('fixed','provider_site','remotely','scheduled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed',
  `is_custom_offer` tinyint(1) NOT NULL DEFAULT '0',
  `is_featured` tinyint(1) DEFAULT '0',
  `required_servicemen` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_advertised` tinyint(1) DEFAULT '0',
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` bigint unsigned DEFAULT NULL,
  `is_random_related_services` int DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `address_id` bigint unsigned DEFAULT NULL,
  `is_advance_payment_enabled` tinyint(1) NOT NULL DEFAULT '0',
  `advance_payment_percentage` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `services_user_id_foreign` (`user_id`),
  KEY `services_parent_id_foreign` (`parent_id`),
  KEY `services_address_id_foreign` (`address_id`),
  CONSTRAINT `services_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `addresses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `services_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `services_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES (1,'{\"ru\":\"Поддерживающая уборка до 50 м²\"}',5000.00,1,'2','hours',5000.00,NULL,5.00,'{\"ru\":null}','{\"ru\":\"<p>Регулярная уборка для квартир-студий и однокомнатных. Влажная уборка пола, вытирание пыли, мытьё санузла и кухонных поверхностей, вынос мусора. Длительность 2 часа.</p>\"}','{\"ru\": null}','{\"ru\":null}',NULL,NULL,'fixed',0,0,'2',0,'{\"ru\":null}','podderzhivayushchaya-uborka-do-50-m2','{\"ru\":null}',17,0,NULL,'2026-06-30 10:18:58','2026-06-30 10:18:58',NULL,0,NULL),(2,'{\"ru\":\"Поддерживающая уборка 50–100 м²\"}',10000.00,1,'3','hours',10000.00,NULL,5.00,'{\"ru\":null}','{\"ru\":\"<p>Регулярная уборка для двух- и трёхкомнатных квартир. Все поверхности, санузел, кухня, полы. Длительность 3 часа.</p>\"}','{\"ru\": null}','{\"ru\":null}',NULL,NULL,'fixed',0,0,'2',0,'{\"ru\":null}','podderzhivayushchaya-uborka-50-100-m2','{\"ru\":null}',17,0,NULL,'2026-06-30 11:01:40','2026-06-30 11:01:40',NULL,0,NULL);
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services_coupons`
--

DROP TABLE IF EXISTS `services_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services_coupons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `coupon_id` bigint unsigned DEFAULT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `services_coupons_coupon_id_foreign` (`coupon_id`),
  KEY `services_coupons_service_id_foreign` (`service_id`),
  CONSTRAINT `services_coupons_coupon_id_foreign` FOREIGN KEY (`coupon_id`) REFERENCES `coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `services_coupons_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services_coupons`
--

LOCK TABLES `services_coupons` WRITE;
/*!40000 ALTER TABLE `services_coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `services_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `values` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'{\"agora\": {\"app_id\": \"qwertyuiopasdfghjklzxcvbnm\", \"certificate\": \"mnbvcxzlkjhgfdsapoiuytrewq\"}, \"email\": {\"mail_host\": \"smtp.gmail.com\", \"mail_port\": 587, \"mail_mailer\": \"smtp\", \"mail_password\": \"\", \"mail_username\": \"\", \"mail_from_name\": \"Laravel\", \"mail_encryption\": \"tls\", \"mail_from_address\": \"\"}, \"google\": {\"client_id\": \"\", \"redirect_url\": \"\", \"client_secret\": \"\"}, \"general\": {\"mode\": \"light\", \"favicon\": \"/admin/images/faviconIcon.png\", \"copyright\": \"Copyright 2026 © Laravel — Bonapartov V.A.\", \"dark_logo\": \"/admin/images/logo.png\", \"site_name\": \"Laravel\", \"light_logo\": \"/admin/images/Logo-Light.png\", \"country_code\": 7, \"platform_fees\": 10, \"default_timezone\": \"Europe/Moscow\", \"min_booking_amount\": 100, \"platform_fees_type\": \"fixed\", \"default_currency_id\": 1, \"default_language_id\": 1, \"default_sms_gateway\": \"Smsru\", \"firebase_server_key\": \"\", \"fallback_sms_gateway\": \"Smsc\", \"cancellation_restriction_hours\": 1}, \"firebase\": {\"service_json\": null, \"yandex_map_api_key\": \"\"}, \"activation\": {\"cash\": \"1\", \"blogs_enable\": \"1\", \"coupon_enable\": \"1\", \"wallet_enable\": \"1\", \"become_provider\": \"1\", \"free_trial_plan\": \"1\", \"maintenance_mode\": \"1\", \"additional_services\": \"1\", \"default_credentials\": \"1\", \"extra_charge_status\": \"1\", \"force_update_in_app\": \"0\", \"social_login_enable\": \"1\", \"subscription_enable\": \"1\", \"platform_fees_status\": \"1\", \"service_auto_approve\": \"1\", \"provider_auto_approve\": \"1\"}, \"social_login\": {\"client_id\": \"\", \"redirect_url\": \"http://localhost/auth/callback/google\", \"client_secret\": \"\"}, \"service_request\": {\"status\": \"1\", \"default_tax_id\": \"1\", \"per_serviceman_commission\": \"5\"}, \"google_reCaptcha\": {\"secret\": \"\", \"status\": \"0\", \"site_key\": \"\"}, \"subscription_plan\": {\"free_trial_days\": 7, \"free_trial_enabled\": \"1\"}, \"provider_commissions\": {\"status\": \"1\", \"min_withdraw_amount\": 500, \"default_commission_rate\": 10, \"is_category_based_commission\": \"1\"}, \"default_creation_limits\": {\"allowed_max_services\": 5, \"allowed_max_addresses\": 5, \"allowed_max_servicemen\": 10, \"allowed_max_service_packages\": 3}}','2026-05-27 14:38:11','2026-05-27 14:43:48'),(2,'{\"agora\": {\"app_id\": \"qwertyuiopasdfghjklzxcvbnm\", \"certificate\": \"mnbvcxzlkjhgfdsapoiuytrewq\"}, \"email\": {\"mail_host\": \"smtp.gmail.com\", \"mail_port\": 587, \"mail_mailer\": \"smtp\", \"mail_password\": \"\", \"mail_username\": \"\", \"mail_from_name\": \"Laravel\", \"mail_encryption\": \"tls\", \"mail_from_address\": \"\"}, \"google\": {\"client_id\": \"\", \"redirect_url\": \"\", \"client_secret\": \"\"}, \"general\": {\"mode\": \"light\", \"favicon\": \"/admin/images/faviconIcon.png\", \"copyright\": \"Copyright 2026 © Laravel — Bonapartov V.A.\", \"dark_logo\": \"/admin/images/logo.png\", \"site_name\": \"Laravel\", \"light_logo\": \"/admin/images/Logo-Light.png\", \"country_code\": 7, \"platform_fees\": 10, \"default_timezone\": \"Europe/Moscow\", \"min_booking_amount\": 100, \"platform_fees_type\": \"fixed\", \"default_currency_id\": 1, \"default_language_id\": null, \"default_sms_gateway\": \"Smsru\", \"firebase_server_key\": \"\", \"fallback_sms_gateway\": \"Smsc\", \"cancellation_restriction_hours\": 1}, \"firebase\": {\"service_json\": null, \"yandex_map_api_key\": \"\"}, \"activation\": {\"cash\": \"1\", \"blogs_enable\": \"1\", \"coupon_enable\": \"1\", \"wallet_enable\": \"1\", \"become_provider\": \"1\", \"free_trial_plan\": \"1\", \"maintenance_mode\": \"1\", \"additional_services\": \"1\", \"default_credentials\": \"1\", \"extra_charge_status\": \"1\", \"force_update_in_app\": \"0\", \"social_login_enable\": \"1\", \"subscription_enable\": \"1\", \"platform_fees_status\": \"1\", \"service_auto_approve\": \"1\", \"provider_auto_approve\": \"1\"}, \"social_login\": {\"client_id\": \"\", \"redirect_url\": \"http://localhost/auth/callback/google\", \"client_secret\": \"\"}, \"service_request\": {\"status\": \"1\", \"default_tax_id\": \"1\", \"per_serviceman_commission\": \"5\"}, \"google_reCaptcha\": {\"secret\": \"\", \"status\": \"0\", \"site_key\": \"\"}, \"subscription_plan\": {\"free_trial_days\": 7, \"free_trial_enabled\": \"1\"}, \"provider_commissions\": {\"status\": \"1\", \"min_withdraw_amount\": 500, \"default_commission_rate\": 10, \"is_category_based_commission\": \"1\"}, \"default_creation_limits\": {\"allowed_max_services\": 5, \"allowed_max_addresses\": 5, \"allowed_max_servicemen\": 10, \"allowed_max_service_packages\": 3}}','2026-05-28 07:40:58','2026-05-28 07:40:58');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_templates`
--

DROP TABLE IF EXISTS `sms_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `url` longtext COLLATE utf8mb4_unicode_ci,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_templates`
--

LOCK TABLES `sms_templates` WRITE;
/*!40000 ALTER TABLE `sms_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `states` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `states_country_id_foreign` (`country_id`),
  CONSTRAINT `states_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscribes`
--

DROP TABLE IF EXISTS `subscribes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscribes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `email` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscribes`
--

LOCK TABLES `subscribes` WRITE;
/*!40000 ALTER TABLE `subscribes` DISABLE KEYS */;
/*!40000 ALTER TABLE `subscribes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_langs`
--

DROP TABLE IF EXISTS `system_langs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_langs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_locale` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_rtl` int DEFAULT '0',
  `status` int DEFAULT '1',
  `system_reserve` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_langs`
--

LOCK TABLES `system_langs` WRITE;
/*!40000 ALTER TABLE `system_langs` DISABLE KEYS */;
INSERT INTO `system_langs` VALUES (1,'Russian','ru',NULL,'ru_RU',0,1,1,'2026-05-27 14:41:54','2026-05-27 14:41:54',NULL),(2,'English','en',NULL,'en_US',0,1,0,'2026-06-14 19:24:50','2026-06-14 19:24:50',NULL);
/*!40000 ALTER TABLE `system_langs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'blog',
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_by_id` bigint unsigned NOT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tags_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `tags_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxes`
--

DROP TABLE IF EXISTS `taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taxes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint unsigned DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` decimal(8,2) DEFAULT NULL,
  `status` int NOT NULL DEFAULT '1',
  `created_by_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taxes_created_by_id_foreign` (`created_by_id`),
  KEY `taxes_zone_id_foreign` (`zone_id`),
  CONSTRAINT `taxes_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `taxes_zone_id_foreign` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxes`
--

LOCK TABLES `taxes` WRITE;
/*!40000 ALTER TABLE `taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `taxes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testimonials`
--

DROP TABLE IF EXISTS `testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `testimonials` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `rating` int DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testimonials`
--

LOCK TABLES `testimonials` WRITE;
/*!40000 ALTER TABLE `testimonials` DISABLE KEYS */;
/*!40000 ALTER TABLE `testimonials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme_options`
--

DROP TABLE IF EXISTS `theme_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `theme_options` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `options` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme_options`
--

LOCK TABLES `theme_options` WRITE;
/*!40000 ALTER TABLE `theme_options` DISABLE KEYS */;
INSERT INTO `theme_options` VALUES (1,'{\"seo\": {\"og_image\": null, \"og_title\": \"Laravel Marketplace: Uniting Vendors for Shopping Excellence\", \"meta_tags\": \"Laravel Marketplace: Where Vendors Shine Together\", \"meta_title\": \"Online Marketplace, Vendor Collaboration, E-commerce Platform\", \"og_description\": \"Experience a unique shopping journey at Laravel Marketplace, where vendors collaborate to provide a vast array of products. Explore, shop, and connect in one convenient destination.\", \"meta_description\": \"Discover Laravel Marketplace – a vibrant online platform where vendors unite to showcase their products, creating a diverse shopping experience. Explore a wide range of offerings and connect with sellers on a single platform.\"}, \"footer\": {\"pages\": [{\"name\": \"Privacy Policy\", \"slug\": \"privacy-policy\"}, {\"name\": \"Terms & Conditions\", \"slug\": \"terms-conditions\"}, {\"name\": \"Contact Us\", \"slug\": \"contact-us\"}, {\"name\": \"About Us\", \"slug\": \"about-us\"}], \"others\": [{\"name\": \"My Account\", \"slug\": \"account/profile\"}, {\"name\": \"Wishlist\", \"slug\": \"wishlist\"}, {\"name\": \"Bookings\", \"slug\": \"booking\"}, {\"name\": \"Providers\", \"slug\": \"providers\"}, {\"name\": \"Services\", \"slug\": \"service\"}], \"useful_link\": [{\"name\": \"Home\", \"slug\": \"/\"}, {\"name\": \"Categories\", \"slug\": \"category\"}, {\"name\": \"Services\", \"slug\": \"service\"}, {\"name\": \"Providers\", \"slug\": \"providers\"}], \"footer_copyright\": \"©2026 Laravel — Bonapartov V.A.\", \"become_a_provider\": {\"description\": \"Earn more and deliver your service to worldwide.\", \"become_a_provider_enable\": true}}, \"header\": {\"home\": true, \"blogs\": true, \"booking\": true, \"services\": true, \"categories\": true}, \"general\": {\"site_title\": \"Laravel\", \"footer_logo\": \"/frontend/images/logo/dark-logo.png\", \"header_logo\": \"/frontend/images/logo/dark-logo.png\", \"favicon_icon\": \"/frontend/images/logo/favicon-icon.png\", \"site_tagline\": \"Your One-Stop Solution for for your home services\", \"app_store_url\": \"https://www.apple.com/in/app-store/\", \"google_play_store_url\": \"https://play.google.com/store/apps/\", \"breadcrumb_description\": \"Select a service from the below category list that correlates with your needs. It includes 15+ categories with 560+ different services in various sector.\"}, \"about_us\": {\"title\": \"Our Mission\", \"status\": true, \"banners\": [{\"count\": \"3.5\", \"title\": \"Years Experience\"}, {\"count\": \"520\", \"title\": \"Positive Reviews\"}, {\"count\": \"10000\", \"title\": \"Trusted Client\"}, {\"count\": \"60\", \"title\": \"Team Member\"}], \"sub_title1\": \"Delivering Excellence:\", \"sub_title2\": \"Empowering Our Clients:\", \"sub_title3\": \"Fostering Innovation:\", \"sub_title4\": \"Building Strong Relationships:\", \"sub_title5\": \"Contributing to the Community:\", \"description\": \"At Laravel, our mission is to be more than just a service provider—we aim to be a trusted partner in your journey to success. We are committed to:\", \"description1\": \"We deliver quality with precision, consistently exceeding expectations.\", \"description2\": \"We provide tools and insights to empower your success now and in the future.\", \"description3\": \"We embrace innovation, continuously improving to keep our clients ahead\", \"description4\": \"We view clients as partners, building trust through open communication and collaboration.\", \"description5\": \"Committed to community impact, we believe our success is linked to the well-being of those we serve.\", \"provider_ids\": [], \"banner_status\": true, \"provider_title\": \"Expert provider by rating\", \"provider_status\": true, \"left_bg_image_url\": \"/frontend/images/categories/electrician/7.jpg\", \"testimonial_title\": \"What our user say about us.\", \"right_bg_image_url\": \"/frontend/images/categories/painter/6.jpg\", \"testimonial_status\": true}, \"contact_us\": {\"email\": \"4nvg3@navalcadets.com\", \"title\": \"Get In Touch\", \"contact\": \"0123456789\", \"location\": \"4 Askern Rd, Doncaster, South Yorkshire, United Kingdom.\", \"description\": \"We improve and grow because of your ideas, queries, and criticism. We are available to listen, whether you have a recommendation, are having a problem, or simply want to talk about your experience.Use the form below or any of the other available contact options to get in touch with us.\", \"header_title\": \"Contact Us\", \"google_map_embed_url\": \"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d303910.6327655508!2d-1.6735875209114677!3d53.48093683253613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4878e2a8b277ed2f%3A0x3a10679c640c8f99!2sSouth%20Yorkshire%2C%20UK!5e0!3m2!1sen!2sin!4v1720436526214!5m2!1sen!2sin\"}, \"pagination\": {\"blog_per_page\": 12, \"service_per_page\": 12, \"provider_per_page\": 12, \"categories_per_page\": 12, \"service_list_per_page\": 12, \"provider_list_per_page\": 12, \"service_package_per_page\": 12}, \"authentication\": {\"title\": \"Welcome to Laravel\", \"auth_images\": \"/frontend/images/auth/girl.png\", \"description\": \"Simply touch and pick to have all of your products and services delivered to your door.\", \"header_logo\": \"/frontend/images/logo/light-logo.png\", \"app_store_url\": \"https: //www.apple.com/in/app-store/\", \"google_play_store_url\": \"https: //play.google.com/store/apps/\"}, \"privacy_policy\": {\"banners\": []}, \"terms_and_conditions\": {\"banners\": []}}','2026-05-27 14:38:11','2026-05-27 14:38:11');
/*!40000 ALTER TABLE `theme_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_slots`
--

DROP TABLE IF EXISTS `time_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_slots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `provider_id` bigint unsigned DEFAULT NULL,
  `serviceman_id` bigint unsigned DEFAULT NULL,
  `time_slots` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `time_slots_provider_id_foreign` (`provider_id`),
  KEY `time_slots_serviceman_id_foreign` (`serviceman_id`),
  CONSTRAINT `time_slots_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `time_slots_serviceman_id_foreign` FOREIGN KEY (`serviceman_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_slots`
--

LOCK TABLES `time_slots` WRITE;
/*!40000 ALTER TABLE `time_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `time_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `time_zones`
--

DROP TABLE IF EXISTS `time_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_zones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `time_zones`
--

LOCK TABLES `time_zones` WRITE;
/*!40000 ALTER TABLE `time_zones` DISABLE KEYS */;
/*!40000 ALTER TABLE `time_zones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `wallet_id` bigint unsigned DEFAULT NULL,
  `booking_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(8,2) NOT NULL DEFAULT '0.00',
  `type` enum('credit','debit') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `detail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `wallet_bonus_id` bigint unsigned DEFAULT NULL,
  `wallet_bonus_amount` bigint unsigned DEFAULT NULL,
  `is_admin_funded` int DEFAULT '0',
  `max_bonus` decimal(12,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  KEY `transactions_wallet_id_foreign` (`wallet_id`),
  KEY `transactions_booking_id_foreign` (`booking_id`),
  KEY `transactions_from_foreign` (`from`),
  KEY `transactions_wallet_bonus_id_foreign` (`wallet_bonus_id`),
  CONSTRAINT `transactions_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_from_foreign` FOREIGN KEY (`from`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_wallet_bonus_id_foreign` FOREIGN KEY (`wallet_bonus_id`) REFERENCES `wallet_bonuses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_documents`
--

DROP TABLE IF EXISTS `user_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `document_id` bigint unsigned NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `identity_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_documents_user_id_foreign` (`user_id`),
  KEY `user_documents_document_id_foreign` (`document_id`),
  CONSTRAINT `user_documents_document_id_foreign` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_documents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_documents`
--

LOCK TABLES `user_documents` WRITE;
/*!40000 ALTER TABLE `user_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_expertise_services`
--

DROP TABLE IF EXISTS `user_expertise_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_expertise_services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `service_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_expertise_services_user_id_foreign` (`user_id`),
  KEY `user_expertise_services_service_id_foreign` (`service_id`),
  CONSTRAINT `user_expertise_services_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_expertise_services_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_expertise_services`
--

LOCK TABLES `user_expertise_services` WRITE;
/*!40000 ALTER TABLE `user_expertise_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_expertise_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_languages`
--

DROP TABLE IF EXISTS `user_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_languages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `language_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_languages_user_id_foreign` (`user_id`),
  KEY `user_languages_language_id_foreign` (`language_id`),
  CONSTRAINT `user_languages_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_languages_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_languages`
--

LOCK TABLES `user_languages` WRITE;
/*!40000 ALTER TABLE `user_languages` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_subscriptions`
--

DROP TABLE IF EXISTS `user_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_subscriptions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `user_plan_id` bigint unsigned DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `total` decimal(10,2) NOT NULL,
  `allowed_max_services` int unsigned NOT NULL,
  `allowed_max_addresses` int unsigned NOT NULL,
  `allowed_max_servicemen` int unsigned NOT NULL,
  `allowed_max_service_packages` int unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_included_free_trial` tinyint(1) NOT NULL DEFAULT '0',
  `payment_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING',
  `product_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_app_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_app_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_subscriptions_user_id_foreign` (`user_id`),
  KEY `user_subscriptions_user_plan_id_foreign` (`user_plan_id`),
  CONSTRAINT `user_subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_subscriptions_user_plan_id_foreign` FOREIGN KEY (`user_plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_subscriptions`
--

LOCK TABLES `user_subscriptions` WRITE;
/*!40000 ALTER TABLE `user_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_zone_permissions`
--

DROP TABLE IF EXISTS `user_zone_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_zone_permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `zone_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_zone_permissions_user_id_zone_id_unique` (`user_id`,`zone_id`),
  KEY `user_zone_permissions_zone_id_foreign` (`zone_id`),
  CONSTRAINT `user_zone_permissions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_zone_permissions_zone_id_foreign` FOREIGN KEY (`zone_id`) REFERENCES `zones` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_zone_permissions`
--

LOCK TABLES `user_zone_permissions` WRITE;
/*!40000 ALTER TABLE `user_zone_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_zone_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `onboarding_completed` tinyint(1) NOT NULL DEFAULT '0',
  `onboarding_step` tinyint NOT NULL DEFAULT '0',
  `onboarding_blocked` tinyint(1) NOT NULL DEFAULT '0',
  `onboarding_blocked_reason` text COLLATE utf8mb4_unicode_ci,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` longtext COLLATE utf8mb4_unicode_ci,
  `system_reserve` int NOT NULL DEFAULT '0',
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `served` int DEFAULT NULL,
  `phone` bigint DEFAULT NULL,
  `code` bigint DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `allow_all_zones` tinyint(1) NOT NULL DEFAULT '0',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `type` enum('company','freelancer') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `fcm_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experience_interval` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `experience_duration` int DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_by` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_id` bigint unsigned DEFAULT NULL,
  `location_cordinates` json DEFAULT NULL,
  `referral_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referred_by_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_referral_code_unique` (`referral_code`),
  KEY `users_provider_id_foreign` (`provider_id`),
  KEY `users_created_by_foreign` (`created_by`),
  KEY `users_company_id_foreign` (`company_id`),
  KEY `users_referred_by_id_foreign` (`referred_by_id`),
  CONSTRAINT `users_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `users_referred_by_id_foreign` FOREIGN KEY (`referred_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (17,0,0,0,NULL,'admin','admin@example.com','admin',1,'$2y$10$BULMy8s8s9vmsB0YfXT9Z.d2M0cET1NuNuDhms7JvO/vx.oAJnxUe',NULL,NULL,NULL,NULL,1,0,0,0,NULL,'2026-05-27 14:39:46',NULL,NULL,NULL,NULL,NULL,'2026-05-27 14:39:46','2026-05-27 14:39:46',NULL,'3ru6LwkMii',NULL,NULL,NULL,NULL),(18,0,0,0,NULL,'Thomas Taylor','user@example.com','thomas-taylor',1,'$2y$10$EydcE7Peo/49akUfhWGvUer69e02XrLADG.sLb1E/G7sZX9VpipH2',NULL,NULL,NULL,NULL,1,0,0,0,NULL,'2026-05-27 14:39:46',NULL,NULL,NULL,NULL,NULL,'2026-05-27 14:39:46','2026-05-27 14:39:46',NULL,'wLZlB90AkM',NULL,NULL,NULL,NULL),(19,0,0,0,NULL,'Robert Davis','provider@example.com','robert-davis',1,'$2y$10$2o66XmxFK0VyK0LdaS.GreIZ43uEorie7Ft8hgefklwVY.pgyZD.W',NULL,NULL,NULL,NULL,1,0,0,0,'company','2026-05-27 14:39:46','cGIuLSY3QAOkMzeFkgHO3u:APA91bGhbG2rPHZbvLnJbEReCtxGuuHMRGQ_yBQZ2SMvQfzvSNBHAckHH3u5i75q2i9lLj909GN0ucA47m4V-GH-2nA9fJtzVYp1mdpSua1C1XKOspjcNeQ','years',2,NULL,NULL,'2026-05-27 14:39:46','2026-05-28 10:13:38',NULL,'iBYN9RNDfz',1,'{\"lat\": 59.548143, \"lng\": 30.0883888}',NULL,NULL),(20,0,0,0,NULL,'Admin','admin@example.com','admin-2',0,'$2y$10$IxdGMUDnwPPjufZyXoTLaeyZxuF52PZBDlXy.Lw3IUdCBFa5jIG8q',NULL,NULL,NULL,NULL,1,0,0,0,NULL,'2026-05-27 14:40:00',NULL,NULL,NULL,NULL,NULL,'2026-05-27 14:40:00','2026-05-27 14:40:00',NULL,'CwrFJzcKRf',NULL,NULL,NULL,NULL),(21,0,0,0,NULL,'Serviceman','servicemen@example.com','serviceman',0,'$2y$10$6z.Cx0OxTGmraMRoaZJGvuGqveUxQZGLZMoK/XpDSCQSmXi0hk6yu',NULL,NULL,NULL,NULL,1,0,0,0,NULL,'2026-05-27 14:45:51',NULL,NULL,NULL,NULL,NULL,'2026-05-27 14:45:51','2026-05-27 14:45:51',NULL,'cOJjjS5VLY',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video_consultations`
--

DROP TABLE IF EXISTS `video_consultations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `video_consultations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `meeting_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `agenda` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `topic` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `platform` enum('google_meet','zoom') COLLATE utf8mb4_unicode_ci DEFAULT 'zoom',
  `type` enum('instant','scheduled','recurring') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` longtext COLLATE utf8mb4_unicode_ci,
  `start_time` timestamp NULL DEFAULT NULL,
  `end_time` timestamp NULL DEFAULT NULL,
  `pre_schedule` int DEFAULT '0',
  `schedule_for` longtext COLLATE utf8mb4_unicode_ci,
  `template_id` longtext COLLATE utf8mb4_unicode_ci,
  `start_url` longtext COLLATE utf8mb4_unicode_ci,
  `join_url` longtext COLLATE utf8mb4_unicode_ci,
  `event_id` longtext COLLATE utf8mb4_unicode_ci,
  `settings` json DEFAULT NULL,
  `created_by_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `video_consultations_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `video_consultations_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video_consultations`
--

LOCK TABLES `video_consultations` WRITE;
/*!40000 ALTER TABLE `video_consultations` DISABLE KEYS */;
/*!40000 ALTER TABLE `video_consultations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallet_bonuses`
--

DROP TABLE IF EXISTS `wallet_bonuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallet_bonuses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` enum('fixed','percentage') COLLATE utf8mb4_unicode_ci DEFAULT 'fixed',
  `bonus` decimal(10,2) DEFAULT '0.00',
  `min_top_up_amount` decimal(10,2) DEFAULT '0.00',
  `max_bonus` decimal(10,2) DEFAULT '0.00',
  `status` int DEFAULT '1',
  `is_admin_funded` int DEFAULT '0',
  `created_by_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `usage_limit_per_user` int DEFAULT NULL,
  `total_usage_limit` int DEFAULT NULL,
  `is_unlimited` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `wallet_bonuses_created_by_id_foreign` (`created_by_id`),
  CONSTRAINT `wallet_bonuses_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallet_bonuses`
--

LOCK TABLES `wallet_bonuses` WRITE;
/*!40000 ALTER TABLE `wallet_bonuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `wallet_bonuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wallets`
--

DROP TABLE IF EXISTS `wallets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wallets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `consumer_id` bigint unsigned DEFAULT NULL,
  `balance` decimal(8,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wallets_consumer_id_foreign` (`consumer_id`),
  CONSTRAINT `wallets_consumer_id_foreign` FOREIGN KEY (`consumer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wallets`
--

LOCK TABLES `wallets` WRITE;
/*!40000 ALTER TABLE `wallets` DISABLE KEYS */;
/*!40000 ALTER TABLE `wallets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraw_requests`
--

DROP TABLE IF EXISTS `withdraw_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraw_requests` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `amount` decimal(8,2) DEFAULT '0.00',
  `message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `admin_message` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `provider_wallet_id` bigint unsigned DEFAULT NULL,
  `provider_id` bigint unsigned DEFAULT NULL,
  `payment_type` enum('paypal','bank') COLLATE utf8mb4_unicode_ci DEFAULT 'bank',
  `is_used` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `withdraw_requests_provider_wallet_id_foreign` (`provider_wallet_id`),
  KEY `withdraw_requests_provider_id_foreign` (`provider_id`),
  CONSTRAINT `withdraw_requests_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `withdraw_requests_provider_wallet_id_foreign` FOREIGN KEY (`provider_wallet_id`) REFERENCES `provider_wallets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraw_requests`
--

LOCK TABLES `withdraw_requests` WRITE;
/*!40000 ALTER TABLE `withdraw_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdraw_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `zones`
--

DROP TABLE IF EXISTS `zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `place_points` geometry DEFAULT NULL,
  `locations` json DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_by_id` bigint unsigned DEFAULT NULL,
  `currency_id` bigint unsigned DEFAULT NULL,
  `payment_methods` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `zones_name_unique` (`name`),
  KEY `zones_created_by_id_foreign` (`created_by_id`),
  KEY `zones_currency_id_foreign` (`currency_id`),
  CONSTRAINT `zones_created_by_id_foreign` FOREIGN KEY (`created_by_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `zones_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `zones`
--

LOCK TABLES `zones` WRITE;
/*!40000 ALTER TABLE `zones` DISABLE KEYS */;
INSERT INTO `zones` VALUES (1,'{\"ru\":\"СПБ Васильевский остров\"}',_binary '\0\0\0\0\0\0\0\0\0\0\0\0\0/>�\�0>@w\�\�Y�M@\�=��,>@SVf��M@�>��+>@s�\�\�2�M@�>�7/>@��\�\�M@R>�\Z=>@:��C�\�M@\�=�\�B>@p\�Au\�M@\�=�\"D>@L9Mʹ\�M@�=\�E>@���\�M@�\�\Z1\�F>@!i|U\�M@:\�\Z�:K>@\��U\�\�M@G\�\Z\�N>@�5:jE�M@�\�\Z�rO>@؇7��M@�\�\Z1{N>@\�\��M@p\�\Z1~K>@�\��/�M@C\�\Z1�F>@HB\��M@\�\�\ZqTD>@]L��]�M@�\�\Z�CB>@��\��M@]\�\Z��8>@��{C��M@\�\'�}4>@BVDu��M@/>�\�0>@w\�\�Y�M@','[{\"lat\": 59.96367739907709, \"lng\": 30.19062257237811}, {\"lat\": 59.95369176861678, \"lng\": 30.174829725698427}, {\"lat\": 59.939052199248955, \"lng\": 30.170023207143743}, {\"lat\": 59.92733587276928, \"lng\": 30.184442762807784}, {\"lat\": 59.91837352680229, \"lng\": 30.238687757924986}, {\"lat\": 59.91764092000115, \"lng\": 30.26091790624042}, {\"lat\": 59.91958013792708, \"lng\": 30.266153578237493}, {\"lat\": 59.927766693596624, \"lng\": 30.269758467153498}, {\"lat\": 59.932296284199765, \"lng\": 30.27704150108632}, {\"lat\": 59.9362590294709, \"lng\": 30.293864316027737}, {\"lat\": 59.93961837618146, \"lng\": 30.305022305529665}, {\"lat\": 59.942719008555144, \"lng\": 30.310343808215233}, {\"lat\": 59.94607769867625, \"lng\": 30.306567257922257}, {\"lat\": 59.94676661855451, \"lng\": 30.29489428428944}, {\"lat\": 59.9509859393731, \"lng\": 30.275668210070695}, {\"lat\": 59.95597954108254, \"lng\": 30.266913479846092}, {\"lat\": 59.95821780713667, \"lng\": 30.25884539512928}, {\"lat\": 59.965706286720064, \"lng\": 30.2210798921996}, {\"lat\": 59.96565118633974, \"lng\": 30.20348344164845}, {\"lat\": 59.96367739907709, \"lng\": 30.19062257237811}]',1,17,1,'[\"cloudpayments\", \"yookassa\"]','2026-05-28 10:04:36','2026-05-28 10:04:36',NULL),(2,'{\"ru\":\"Гатчина ЛО\"}',_binary '\0\0\0\0\0\0\0\0\0\0N\0\0\0#d�>@�\�\�\\�\�M@�#\�@>@�\��t\�M@.#l^>@*�\�i9\�M@\�#�>@�\�\��\�M@A#\�\�>@U\�XM\�\�M@\�#\��>@@\�e\��\�M@\�#L}>@!UP\�\�M@�#��>@D\'\0\�\�M@w#L>@��\�	\�M@�\�V�	>@\�ՇN\�M@z\�VEi>@�2\�\�:\�M@/\�V�9>@?��=�\�M@\�\�V��>@��k�\�M@	\�V-\'>@tK\�+�\�M@%�\�w�>@\�[O��\�M@~�\�+\Z>@\"}װ\�\�M@�\��\Z>@�6\�\�\�M@\�\�\�h>@u�\�\�M@\�ę\�>@�\�9�J\�M@ř\�\�>@�Ba�\�M@\�C\�]�>@\�\nM\�\�M@D\�}�>@��B\�\�M@\�C\�-9>@��\�\�S\�M@9��$>@]�#��\�M@{��\�>@�XR�\�M@��.!>@!#!C�\�M@��#\r!>@��\��\�\�M@\���^!>@d0\�\�l\�M@\���� >@\�:�\�:\�M@\���� >@�#��\�\�M@�\� >@wAS�\�\�M@�3�!>@\�@\�!\�M@G\�,J_\">@<\�#\�M@D\�\��\">@\�\��1�\�M@�\�\�\\L#>@�\�b\�M@d\�\�<k$>@D�\�\�\�\�M@]�ߤ�%>@ʳt�\�M@#�\�\�z&>@\�\�L`\�M@ �\�$,\'>@�dyY�\�M@�\�\�(>@�\�U[\�M@:�ߤB\'>@�\�ĩ\�M@��\�Tu&>@B\��\�\�M@s�\�\�$>@�;�o\�\�M@\\�ߴ\�\">@\r\'�a\�\�M@W�ߔ�!>@+\�{\�M@\�߄\�>@ܙ\�\�\�\�M@��\�\'>@T��\�M@X�\�\�7>@\�.�~\�M@&�\�\�Y>@v9\�\�M@��\�\�>@�[��P\�M@��ߤj>@!2&\"\�M@\n�\�d�>@\�\�(\�	\�M@_�\�\�>@p\nu�\�\�M@N�\�\�>@�\�0+�\�M@c�\�T�>@\�d\�\rt\�M@K�ߴ,>@�f\�8\�M@��\�\�>@\�/\�\��\�M@\�\�t\�>@Ӑu̹\�M@�k��>@i�&0\�\�M@\�j��\�\Z>@\���\�M@\�j��\�\Z>@\�8R�4\�M@Ik���>@wl�y�\�M@2T\�c>@�a��\�\�M@ET\�S�>@�y\�K\�\�M@�S\�\�>@�\�\Z�\�\�M@jT\�3\�>@M�\�\��\�M@yT\�SW>@8h˱\�M@�T\�s\�>@\�\�Ԏ\�M@]T\�\�>@U\�V@\�M@WT\�C\�>@C�Ѹ\�\�M@�T\�I>@\�\�O�\�M@\�T哌>@\�fz�\�M@\�S\�h>@>~\�ȋ\�M@�T\�c�>@0q֪k\�M@�T\�\�>@�09�2\�M@�T\�_>@U\�P\�M@>T\�\\>@\�\'�\�\�\�M@#d�>@�\�\�\\�\�M@','[{\"lat\": 59.55152473172128, \"lng\": 30.084524422683415}, {\"lat\": 59.550435435913926, \"lng\": 30.08692768196074}, {\"lat\": 59.54862712682441, \"lng\": 30.08737829307524}, {\"lat\": 59.54743969016043, \"lng\": 30.08617666343659}, {\"lat\": 59.546579044673415, \"lng\": 30.088987618484175}, {\"lat\": 59.54672067139683, \"lng\": 30.08978155235259}, {\"lat\": 59.547788299775085, \"lng\": 30.09175565818755}, {\"lat\": 59.54772293574812, \"lng\": 30.092721253432913}, {\"lat\": 59.5471782305737, \"lng\": 30.093815594710986}, {\"lat\": 59.54927156394517, \"lng\": 30.09780343407177}, {\"lat\": 59.54867241540848, \"lng\": 30.09926255577587}, {\"lat\": 59.544685081863264, \"lng\": 30.094627698598135}, {\"lat\": 59.54452710397799, \"lng\": 30.09595807426952}, {\"lat\": 59.54449986633643, \"lng\": 30.09825404518627}, {\"lat\": 59.54472617030128, \"lng\": 30.100364201825837}, {\"lat\": 59.54500399133566, \"lng\": 30.10174822167754}, {\"lat\": 59.54582654601633, \"lng\": 30.10451626138089}, {\"lat\": 59.547569641645616, \"lng\": 30.10706972436308}, {\"lat\": 59.54915287800653, \"lng\": 30.108121967355487}, {\"lat\": 59.551799906538626, \"lng\": 30.1088086128633}, {\"lat\": 59.553872709204384, \"lng\": 30.109304306159206}, {\"lat\": 59.55343702560396, \"lng\": 30.11179339612501}, {\"lat\": 59.55724906534288, \"lng\": 30.114153740058125}, {\"lat\": 59.56004418603416, \"lng\": 30.11383239104174}, {\"lat\": 59.56226567582619, \"lng\": 30.115935242909412}, {\"lat\": 59.55930365675032, \"lng\": 30.121600068348847}, {\"lat\": 59.553832625361935, \"lng\": 30.12910674140102}, {\"lat\": 59.550194489391686, \"lng\": 30.130351286383934}, {\"lat\": 59.5486694049234, \"lng\": 30.127647619696926}, {\"lat\": 59.545074288798475, \"lng\": 30.127647619696926}, {\"lat\": 59.54509607854068, \"lng\": 30.12867758795863}, {\"lat\": 59.54788504878725, \"lng\": 30.13138125464564}, {\"lat\": 59.555781154012784, \"lng\": 30.13426650616498}, {\"lat\": 59.55951523725316, \"lng\": 30.135437781638927}, {\"lat\": 59.56284746931525, \"lng\": 30.13788395626049}, {\"lat\": 59.568444003205585, \"lng\": 30.142261321372803}, {\"lat\": 59.57444621608707, \"lng\": 30.14649420220652}, {\"lat\": 59.581063850762845, \"lng\": 30.150313667843736}, {\"lat\": 59.58576506068574, \"lng\": 30.153017334530745}, {\"lat\": 59.58872474351275, \"lng\": 30.156278900692858}, {\"lat\": 59.5911184134365, \"lng\": 30.15336065728466}, {\"lat\": 59.591336011325346, \"lng\": 30.150227837155263}, {\"lat\": 59.58408924203113, \"lng\": 30.14070063073435}, {\"lat\": 59.585155681777835, \"lng\": 30.136409096310537}, {\"lat\": 59.58598269332513, \"lng\": 30.131173424313467}, {\"lat\": 59.58519920921011, \"lng\": 30.124779038021956}, {\"lat\": 59.58391512619753, \"lng\": 30.11778383691113}, {\"lat\": 59.581999792337236, \"lng\": 30.11804132897655}, {\"lat\": 59.57651436722896, \"lng\": 30.11465101678173}, {\"lat\": 59.57276983156743, \"lng\": 30.11276274163524}, {\"lat\": 59.57135463654837, \"lng\": 30.11490850884715}, {\"lat\": 59.570614356903626, \"lng\": 30.116110138485823}, {\"lat\": 59.56935148920931, \"lng\": 30.112977318356425}, {\"lat\": 59.56686916239916, \"lng\": 30.116410545895484}, {\"lat\": 59.566041679304846, \"lng\": 30.12001543481151}, {\"lat\": 59.564212433714594, \"lng\": 30.117869667599603}, {\"lat\": 59.562404866883014, \"lng\": 30.115294746945303}, {\"lat\": 59.5603576253937, \"lng\": 30.11289148766795}, {\"lat\": 59.56217004670785, \"lng\": 30.108353613507635}, {\"lat\": 59.563324295448, \"lng\": 30.10470580924737}, {\"lat\": 59.56410829081269, \"lng\": 30.10470580924737}, {\"lat\": 59.56663437347079, \"lng\": 30.096337317120923}, {\"lat\": 59.56999441253975, \"lng\": 30.08627914761423}, {\"lat\": 59.56986377084445, \"lng\": 30.08194469784618}, {\"lat\": 59.568775070260834, \"lng\": 30.077309840668445}, {\"lat\": 59.56738148194759, \"lng\": 30.07327579831005}, {\"lat\": 59.56792585927357, \"lng\": 30.07164501522898}, {\"lat\": 59.5668588714028, \"lng\": 30.07001423214794}, {\"lat\": 59.564463468888945, \"lng\": 30.07310413693308}, {\"lat\": 59.56124029379005, \"lng\": 30.077610248078106}, {\"lat\": 59.56058690973959, \"lng\": 30.083146327484855}, {\"lat\": 59.55973749145163, \"lng\": 30.08417629574656}, {\"lat\": 59.55895339394572, \"lng\": 30.083618396271454}, {\"lat\": 59.55797324629644, \"lng\": 30.084219211090797}, {\"lat\": 59.55623069088495, \"lng\": 30.08190178250189}, {\"lat\": 59.55488014821733, \"lng\": 30.083489650238747}, {\"lat\": 59.553921665603006, \"lng\": 30.087352031220195}, {\"lat\": 59.55152473172128, \"lng\": 30.084524422683415}]',1,17,1,'[\"cloudpayments\", \"yookassa\"]','2026-05-28 10:09:35','2026-05-28 10:09:35',NULL),(3,'{\"ru\":\"СПб Петроградский р-он\"}',_binary '\0\0\0\0\0\0\0\0\0\0\"\0\0\0�^-�\'<>@ذ\�z��M@|^-\�<>@\�\�r�k�M@Y^-\�\�=>@z\Zդ�M@\�]-\�A>@�\�m4\��M@^-�jC>@\�$����M@^-DE>@F�\�X�M@�^-tKF>@�3\�}�M@@^-${H>@hiY�\��M@�^-@I>@���G��M@�^-tI>@�\"\�\��M@h^-\�lK>@\����E�M@g^-\�wN>@\�3��>�M@�^-�Q>@[\��FU�M@�^-�\�R>@\Z$�Χ�M@Z^-�\�V>@\�>\�&�M@\�]-�V>@\��\�_��M@�6\�U>@�\�S���M@|\�=T>@�\�l��M@\�\�]R>@��p8�M@|\�=<Q>@��0\�Q�M@�\�O>@��\\\�X�M@\�\�\�qN>@q�\�2�M@�\�\�tK>@\�\�\�\��M@\�\�]�J>@\�J�%��M@�\�}I>@x#ԟj�M@\�=rH>@S\�s<�M@\"\�]H>@@p�\�\��M@\�\��XG>@�����M@�\�}4F>@y\�ٿ}�M@\�\�]�C>@\�\�o�M@\�\��&C>@\�\�\�Y�M@$\�=!?>@�Ȟ��M@\�\�}=>@�L���M@�^-�\'<>@ذ\�z��M@','[{\"lat\": 59.96620116834143, \"lng\": 30.23497797114961}, {\"lat\": 59.96422165016256, \"lng\": 30.23446298701875}, {\"lat\": 59.961811641744816, \"lng\": 30.241329442096887}, {\"lat\": 59.959143212943445, \"lng\": 30.254375706745304}, {\"lat\": 59.95781620552014, \"lng\": 30.26334501369111}, {\"lat\": 59.95583618459752, \"lng\": 30.2698252306711}, {\"lat\": 59.95359775712838, \"lng\": 30.27458883388154}, {\"lat\": 59.951402228982985, \"lng\": 30.28312898738496}, {\"lat\": 59.950325936394776, \"lng\": 30.28613306148165}, {\"lat\": 59.94976625039021, \"lng\": 30.28557516200655}, {\"lat\": 59.94744129933062, \"lng\": 30.294630299640833}, {\"lat\": 59.94722601780806, \"lng\": 30.306517849994833}, {\"lat\": 59.94791491374255, \"lng\": 30.31909204585665}, {\"lat\": 59.95043356723161, \"lng\": 30.323769818378615}, {\"lat\": 59.95430804381429, \"lng\": 30.339305172992884}, {\"lat\": 59.95762251305956, \"lng\": 30.336129437519247}, {\"lat\": 59.96528832048968, \"lng\": 30.33492391933989}, {\"lat\": 59.97393994630774, \"lng\": 30.32831174713571}, {\"lat\": 59.97828484452642, \"lng\": 30.320501154484344}, {\"lat\": 59.97905912276386, \"lng\": 30.317325419010707}, {\"lat\": 59.979274196827696, \"lng\": 30.308656519474575}, {\"lat\": 59.978112780228535, \"lng\": 30.3064249215742}, {\"lat\": 59.97488640851381, \"lng\": 30.29475194794138}, {\"lat\": 59.97342368275482, \"lng\": 30.291662043156215}, {\"lat\": 59.97200391634341, \"lng\": 30.285224741520462}, {\"lat\": 59.97058408885725, \"lng\": 30.28299314362009}, {\"lat\": 59.96709879880704, \"lng\": 30.281362360539017}, {\"lat\": 59.96580785725359, \"lng\": 30.278701609196247}, {\"lat\": 59.96477506766426, \"lng\": 30.274238413395484}, {\"lat\": 59.96434472913318, \"lng\": 30.26556951385933}, {\"lat\": 59.96365617581627, \"lng\": 30.262307947697245}, {\"lat\": 59.96507630129856, \"lng\": 30.24660093170603}, {\"lat\": 59.96623817671371, \"lng\": 30.238532846989216}, {\"lat\": 59.96620116834143, \"lng\": 30.23497797114961}]',1,17,1,'[\"cloudpayments\", \"yookassa\"]','2026-05-28 10:12:53','2026-05-28 10:12:53',NULL),(6,'{\"ru\":\"Гатчина ЛО (копия)\"}',_binary '\0\0\0\0\0\0\0\0\0\0N\0\0\0#d�>@�\�\�\\�\�M@�#\�@>@�\��t\�M@.#l^>@*�\�i9\�M@\�#�>@�\�\��\�M@A#\�\�>@U\�XM\�\�M@\�#\��>@@\�e\��\�M@\�#L}>@!UP\�\�M@�#��>@D\'\0\�\�M@w#L>@��\�	\�M@�\�V�	>@\�ՇN\�M@z\�VEi>@�2\�\�:\�M@/\�V�9>@?��=�\�M@\�\�V��>@��k�\�M@	\�V-\'>@tK\�+�\�M@%�\�w�>@\�[O��\�M@~�\�+\Z>@\"}װ\�\�M@�\��\Z>@�6\�\�\�M@\�\�\�h>@u�\�\�M@\�ę\�>@�\�9�J\�M@ř\�\�>@�Ba�\�M@\�C\�]�>@\�\nM\�\�M@D\�}�>@��B\�\�M@\�C\�-9>@��\�\�S\�M@9��$>@]�#��\�M@{��\�>@�XR�\�M@��.!>@!#!C�\�M@��#\r!>@��\��\�\�M@\���^!>@d0\�\�l\�M@\���� >@\�:�\�:\�M@\���� >@�#��\�\�M@�\� >@wAS�\�\�M@�3�!>@\�@\�!\�M@G\�,J_\">@<\�#\�M@D\�\��\">@\�\��1�\�M@�\�\�\\L#>@�\�b\�M@d\�\�<k$>@D�\�\�\�\�M@]�ߤ�%>@ʳt�\�M@#�\�\�z&>@\�\�L`\�M@ �\�$,\'>@�dyY�\�M@�\�\�(>@�\�U[\�M@:�ߤB\'>@�\�ĩ\�M@��\�Tu&>@B\��\�\�M@s�\�\�$>@�;�o\�\�M@\\�ߴ\�\">@\r\'�a\�\�M@W�ߔ�!>@+\�{\�M@\�߄\�>@ܙ\�\�\�\�M@��\�\'>@T��\�M@X�\�\�7>@\�.�~\�M@&�\�\�Y>@v9\�\�M@��\�\�>@�[��P\�M@��ߤj>@!2&\"\�M@\n�\�d�>@\�\�(\�	\�M@_�\�\�>@p\nu�\�\�M@N�\�\�>@�\�0+�\�M@c�\�T�>@\�d\�\rt\�M@K�ߴ,>@�f\�8\�M@��\�\�>@\�/\�\��\�M@\�\�t\�>@Ӑu̹\�M@�k��>@i�&0\�\�M@\�j��\�\Z>@\���\�M@\�j��\�\Z>@\�8R�4\�M@Ik���>@wl�y�\�M@2T\�c>@�a��\�\�M@ET\�S�>@�y\�K\�\�M@�S\�\�>@�\�\Z�\�\�M@jT\�3\�>@M�\�\��\�M@yT\�SW>@8h˱\�M@�T\�s\�>@\�\�Ԏ\�M@]T\�\�>@U\�V@\�M@WT\�C\�>@C�Ѹ\�\�M@�T\�I>@\�\�O�\�M@\�T哌>@\�fz�\�M@\�S\�h>@>~\�ȋ\�M@�T\�c�>@0q֪k\�M@�T\�\�>@�09�2\�M@�T\�_>@U\�P\�M@>T\�\\>@\�\'�\�\�\�M@#d�>@�\�\�\\�\�M@','[{\"lat\": 59.55152473172128, \"lng\": 30.084524422683415}, {\"lat\": 59.550435435913926, \"lng\": 30.08692768196074}, {\"lat\": 59.54862712682441, \"lng\": 30.08737829307524}, {\"lat\": 59.54743969016043, \"lng\": 30.08617666343659}, {\"lat\": 59.546579044673415, \"lng\": 30.088987618484175}, {\"lat\": 59.54672067139683, \"lng\": 30.08978155235259}, {\"lat\": 59.547788299775085, \"lng\": 30.09175565818755}, {\"lat\": 59.54772293574812, \"lng\": 30.092721253432913}, {\"lat\": 59.5471782305737, \"lng\": 30.093815594710986}, {\"lat\": 59.54927156394517, \"lng\": 30.09780343407177}, {\"lat\": 59.54867241540848, \"lng\": 30.09926255577587}, {\"lat\": 59.544685081863264, \"lng\": 30.094627698598135}, {\"lat\": 59.54452710397799, \"lng\": 30.09595807426952}, {\"lat\": 59.54449986633643, \"lng\": 30.09825404518627}, {\"lat\": 59.54472617030128, \"lng\": 30.100364201825837}, {\"lat\": 59.54500399133566, \"lng\": 30.10174822167754}, {\"lat\": 59.54582654601633, \"lng\": 30.10451626138089}, {\"lat\": 59.547569641645616, \"lng\": 30.10706972436308}, {\"lat\": 59.54915287800653, \"lng\": 30.108121967355487}, {\"lat\": 59.551799906538626, \"lng\": 30.1088086128633}, {\"lat\": 59.553872709204384, \"lng\": 30.109304306159206}, {\"lat\": 59.55343702560396, \"lng\": 30.11179339612501}, {\"lat\": 59.55724906534288, \"lng\": 30.114153740058125}, {\"lat\": 59.56004418603416, \"lng\": 30.11383239104174}, {\"lat\": 59.56226567582619, \"lng\": 30.115935242909412}, {\"lat\": 59.55930365675032, \"lng\": 30.121600068348847}, {\"lat\": 59.553832625361935, \"lng\": 30.12910674140102}, {\"lat\": 59.550194489391686, \"lng\": 30.130351286383934}, {\"lat\": 59.5486694049234, \"lng\": 30.127647619696926}, {\"lat\": 59.545074288798475, \"lng\": 30.127647619696926}, {\"lat\": 59.54509607854068, \"lng\": 30.12867758795863}, {\"lat\": 59.54788504878725, \"lng\": 30.13138125464564}, {\"lat\": 59.555781154012784, \"lng\": 30.13426650616498}, {\"lat\": 59.55951523725316, \"lng\": 30.135437781638927}, {\"lat\": 59.56284746931525, \"lng\": 30.13788395626049}, {\"lat\": 59.568444003205585, \"lng\": 30.142261321372803}, {\"lat\": 59.57444621608707, \"lng\": 30.14649420220652}, {\"lat\": 59.581063850762845, \"lng\": 30.150313667843736}, {\"lat\": 59.58576506068574, \"lng\": 30.153017334530745}, {\"lat\": 59.58872474351275, \"lng\": 30.156278900692858}, {\"lat\": 59.5911184134365, \"lng\": 30.15336065728466}, {\"lat\": 59.591336011325346, \"lng\": 30.150227837155263}, {\"lat\": 59.58408924203113, \"lng\": 30.14070063073435}, {\"lat\": 59.585155681777835, \"lng\": 30.136409096310537}, {\"lat\": 59.58598269332513, \"lng\": 30.131173424313467}, {\"lat\": 59.58519920921011, \"lng\": 30.124779038021956}, {\"lat\": 59.58391512619753, \"lng\": 30.11778383691113}, {\"lat\": 59.581999792337236, \"lng\": 30.11804132897655}, {\"lat\": 59.57651436722896, \"lng\": 30.11465101678173}, {\"lat\": 59.57276983156743, \"lng\": 30.11276274163524}, {\"lat\": 59.57135463654837, \"lng\": 30.11490850884715}, {\"lat\": 59.570614356903626, \"lng\": 30.116110138485823}, {\"lat\": 59.56935148920931, \"lng\": 30.112977318356425}, {\"lat\": 59.56686916239916, \"lng\": 30.116410545895484}, {\"lat\": 59.566041679304846, \"lng\": 30.12001543481151}, {\"lat\": 59.564212433714594, \"lng\": 30.117869667599603}, {\"lat\": 59.562404866883014, \"lng\": 30.115294746945303}, {\"lat\": 59.5603576253937, \"lng\": 30.11289148766795}, {\"lat\": 59.56217004670785, \"lng\": 30.108353613507635}, {\"lat\": 59.563324295448, \"lng\": 30.10470580924737}, {\"lat\": 59.56410829081269, \"lng\": 30.10470580924737}, {\"lat\": 59.56663437347079, \"lng\": 30.096337317120923}, {\"lat\": 59.56999441253975, \"lng\": 30.08627914761423}, {\"lat\": 59.56986377084445, \"lng\": 30.08194469784618}, {\"lat\": 59.568775070260834, \"lng\": 30.077309840668445}, {\"lat\": 59.56738148194759, \"lng\": 30.07327579831005}, {\"lat\": 59.56792585927357, \"lng\": 30.07164501522898}, {\"lat\": 59.5668588714028, \"lng\": 30.07001423214794}, {\"lat\": 59.564463468888945, \"lng\": 30.07310413693308}, {\"lat\": 59.56124029379005, \"lng\": 30.077610248078106}, {\"lat\": 59.56058690973959, \"lng\": 30.083146327484855}, {\"lat\": 59.55973749145163, \"lng\": 30.08417629574656}, {\"lat\": 59.55895339394572, \"lng\": 30.083618396271454}, {\"lat\": 59.55797324629644, \"lng\": 30.084219211090797}, {\"lat\": 59.55623069088495, \"lng\": 30.08190178250189}, {\"lat\": 59.55488014821733, \"lng\": 30.083489650238747}, {\"lat\": 59.553921665603006, \"lng\": 30.087352031220195}, {\"lat\": 59.55152473172128, \"lng\": 30.084524422683415}]',1,17,1,'[\"cloudpayments\", \"yookassa\"]','2026-06-30 08:17:07','2026-06-30 08:17:07',NULL),(7,'{\"ru\":\"Кудрово\"}',_binary '\0\0\0\0\0\0\0\0\0\0#\0\0\0{P ���>@Ч\� �\�M@�P ӟ�>@�;\�җ\�M@pP C\�>@��3\�\�M@\�P c��>@\�\�y\�\�M@�P \��>@v>+�\�\�M@uP \�>@��`)U\�M@P 3,�>@ۇ�\�M@�P �\�>@^�R\�\�M@iP �S�>@3\�\� \�M@��\�>@�H�\�m\�M@�rr��>@U\�\'M�\�M@ߺX�>@zBr�\�M@%�SҦ�>@�R�\r)\�M@A_1;��>@;:5�U\�M@�k�9;�>@Qm\�\�M@̕�\�j�>@G\�\�M@\�rh8�>@�\�\�\�M@�A�\�ր>@c\�\�k\r\�M@\�P �\��>@u\�Ȳ\�M@`P #��>@����\�\�M@��}\�9�>@�;\Z \�M@u\�N|Ʌ>@�\�A\�\�M@\���\�T�>@\�8�p�\�M@��k嗃>@�;��\�M@$FlG�>@\�3Y�\�M@(:�|�>@\�\0�c�\�M@�P 3\�>@��Ď\�M@FP �u�>@\"N\��n\�M@LP SN�>@�� \�M@�P S��>@\�\�1\�\�M@FP �u�>@#5\���\�M@�(}\�>�>@[<#\�\�M@ǼNۅ�>@|\�\�\�M@�P �|�>@[\�\"%�\�M@{P ���>@Ч\� �\�M@','[{\"lat\": 59.89560328594214, \"lng\": 30.50638789690904}, {\"lat\": 59.89525829452723, \"lng\": 30.506344981564805}, {\"lat\": 59.89752223513212, \"lng\": 30.51540011919909}, {\"lat\": 59.89741443194727, \"lng\": 30.51857585467273}, {\"lat\": 59.89799656497498, \"lng\": 30.51986331499987}, {\"lat\": 59.901036426697225, \"lng\": 30.52188033617907}, {\"lat\": 59.91047762104839, \"lng\": 30.524111934079453}, {\"lat\": 59.91218019816755, \"lng\": 30.523124881161984}, {\"lat\": 59.915067913443615, \"lng\": 30.520807452573106}, {\"lat\": 59.91741606652925, \"lng\": 30.519103530708986}, {\"lat\": 59.91864933443157, \"lng\": 30.521933701381688}, {\"lat\": 59.919050486048995, \"lng\": 30.523915811179297}, {\"lat\": 59.92312788605751, \"lng\": 30.525982995413568}, {\"lat\": 59.9244905958083, \"lng\": 30.518222522309543}, {\"lat\": 59.92196322485205, \"lng\": 30.51652870243911}, {\"lat\": 59.91991304665698, \"lng\": 30.517256241427994}, {\"lat\": 59.91872953229034, \"lng\": 30.504762495041312}, {\"lat\": 59.91447208252547, \"lng\": 30.503278110702304}, {\"lat\": 59.91170607156021, \"lng\": 30.503426738156612}, {\"lat\": 59.91234183066865, \"lng\": 30.506044574155094}, {\"lat\": 59.91504218970331, \"lng\": 30.5204127723267}, {\"lat\": 59.912544476616155, \"lng\": 30.522605675956957}, {\"lat\": 59.91062744205027, \"lng\": 30.51692150338239}, {\"lat\": 59.9110913301042, \"lng\": 30.514036501750887}, {\"lat\": 59.91065516495058, \"lng\": 30.51280857765633}, {\"lat\": 59.91108363960108, \"lng\": 30.509705525643213}, {\"lat\": 59.910606933768406, \"lng\": 30.507632441891904}, {\"lat\": 59.90963707599097, \"lng\": 30.50570125140123}, {\"lat\": 59.90724463856928, \"lng\": 30.501195140256204}, {\"lat\": 59.90503525218865, \"lng\": 30.50600165881091}, {\"lat\": 59.90386044523114, \"lng\": 30.50570125140123}, {\"lat\": 59.898705975728234, \"lng\": 30.50486585431697}, {\"lat\": 59.89868545151595, \"lng\": 30.50594874069477}, {\"lat\": 59.89615310859351, \"lng\": 30.505808539761784}, {\"lat\": 59.89560328594214, \"lng\": 30.50638789690904}]',1,17,1,'[\"cloudpayments\", \"yookassa\"]','2026-06-30 08:31:50','2026-06-30 08:31:50',NULL);
/*!40000 ALTER TABLE `zones` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-30 17:27:20
